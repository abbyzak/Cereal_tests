const axios = require('axios');
const crypto = require('crypto');
const os = require('os');

class SerialValidator {
    constructor(apiBaseUrl = 'http://127.0.0.1:8000') {
        this.apiBaseUrl = apiBaseUrl;
        this.validateEndpoint = '/api/v1/serial/validate/';
    }

    generateExeHash() {
        const machineInfo = {
            platform: process.platform,
            arch: process.arch,
            hostname: os.hostname(),
            cpus: os.cpus().map(cpu => cpu.model).join(','),
            installationId: crypto.randomUUID()
        };

        const serialized = JSON.stringify(machineInfo, Object.keys(machineInfo).sort());
        return crypto.createHash('sha256').update(serialized).digest('hex');
    }

    async validateSerial(serialCode, exeHash = null) {
        try {
            const hash = exeHash || this.generateExeHash();
            
            console.log('Validating with exe hash:', hash);
            console.log('API URL:', `${this.apiBaseUrl}${this.validateEndpoint}`);
            
            const response = await axios.post(
                `${this.apiBaseUrl}${this.validateEndpoint}`,
                {
                    serial_code: serialCode,
                    exe_hash: hash
                },
                {
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    timeout: 5000,
                    validateStatus: function (status) {
                        return status >= 200 && status < 500;
                    }
                }
            );

            console.log('Response status:', response.status);
            console.log('Response headers:', response.headers);
            console.log('Response data:', response.data);

            return {
                success: true,
                data: response.data
            };
        } catch (error) {
            console.error('Error details:', {
                message: error.message,
                code: error.code,
                response: error.response?.data,
                status: error.response?.status
            });

            if (error.code === 'ECONNREFUSED') {
                return {
                    success: false,
                    error: `Could not connect to the API server at ${this.apiBaseUrl}. Please make sure the server is running.`,
                    status: 0
                };
            } else if (error.code === 'ETIMEDOUT') {
                return {
                    success: false,
                    error: 'Connection to the API server timed out.',
                    status: 0
                };
            } else if (error.response) {
                return {
                    success: false,
                    error: error.response.data.error || 'Validation failed',
                    status: error.response.status
                };
            } else if (error.request) {
                return {
                    success: false,
                    error: 'No response received from server',
                    status: 0
                };
            } else {
                return {
                    success: false,
                    error: error.message,
                    status: 0
                };
            }
        }
    }
}

async function main() {
    const apiUrl = process.env.API_URL || 'http://127.0.0.1:8000';
    console.log('Using API URL:', apiUrl);
    
    const validator = new SerialValidator(apiUrl);
    
    const trialSerial = "TRIAL-C3MF8OXQT6TG";
    console.log('Validating trial serial:', trialSerial);
    
    console.log('\nFirst validation attempt:');
    const result1 = await validator.validateSerial(trialSerial);
    
    if (result1.success) {
        console.log('\nSerial Validation Successful!');
        console.log('===========================');
        console.log(`Serial: ${result1.data.code}`);
        console.log(`Time Remaining: ${result1.data.time_remaining.toFixed(2)} hours`);
        console.log(`Expires At: ${result1.data.expires_at}`);
        console.log(`Is Hash Registered: ${result1.data.is_hash_registered}`);
        
        if (result1.data.first_validated_at && result1.data.is_hash_registered) {
            console.log(`First Validated At: ${result1.data.first_validated_at}`);
            console.log(`Exe Hash: ${result1.data.exe_hash}`);
        }
        
        const exeHash = result1.data.exe_hash;
        
        console.log('\nSecond validation attempt (same machine):');
        const result2 = await validator.validateSerial(trialSerial, exeHash);
        
        if (result2.success) {
            console.log('\nSecond Validation Successful!');
            console.log('===========================');
            console.log(`Serial: ${result2.data.code}`);
            console.log(`Time Remaining: ${result2.data.time_remaining.toFixed(2)} hours`);
        } else {
            console.error('\nSecond Validation Failed:');
            console.error(`Error: ${result2.error}`);
        }
        
        console.log('\nThird validation attempt (different machine):');
        const result3 = await validator.validateSerial(trialSerial);
        
        if (result3.success) {
            console.log('\nThird Validation Successful!');
        } else {
            console.error('\nThird Validation Failed:');
            console.error(`Error: ${result3.error}`);
            console.error(`Status: ${result3.status}`);
        }
    } else {
        console.error('\nValidation Failed:');
        console.error(`Error: ${result1.error}`);
        console.error(`Status: ${result1.status}`);
    }
}

if (require.main === module) {
    main().catch(console.error);
} 