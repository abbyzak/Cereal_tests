from django.db import models
from django.contrib.auth import get_user_model
import uuid
import random
import string
from django.utils import timezone
from django.conf import settings

User = get_user_model()

class FriendCode(models.Model):
    """Model for generating and storing friend invitation codes"""
    code = models.CharField(max_length=20, unique=True)
    creator = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='created_codes')
    hours_offered = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    is_used = models.BooleanField(default=False)
    used_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='used_codes'
    )
    used_at = models.DateTimeField(null=True, blank=True)
    
    @staticmethod
    def generate_code():
        """
        Generate a random friend code.
        """
        # Generate a 16-character code with letters and digits
        chars = string.ascii_uppercase + string.digits
        code = 'FC-' + ''.join(random.choice(chars) for _ in range(12))
        return code
    
    def __str__(self):
        return self.code


class ChatMessage(models.Model):
    """Model for storing chat messages between users"""
    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='sent_messages'
    )
    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='received_messages'
    )
    message = models.TextField(blank=True)
    image = models.ImageField(upload_to='chat_images/', null=True, blank=True)
    timestamp = models.DateTimeField(default=timezone.now)
    is_read = models.BooleanField(default=False)
    
    class Meta:
        ordering = ['timestamp']
    
    def __str__(self):
        return f"Message from {self.sender} to {self.recipient} at {self.timestamp}"
    
    @property
    def has_image(self):
        return bool(self.image)

class ChatRoom(models.Model):
    """Model for a chat room that can have multiple participants"""
    room_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    name = models.CharField(max_length=255, blank=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_rooms')
    created_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.name or 'Unnamed Room'} ({self.room_id})"
    
class ChatRoomParticipant(models.Model):
    """Model for tracking participants in a chat room"""
    room = models.ForeignKey(ChatRoom, on_delete=models.CASCADE, related_name='participants')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='chat_rooms')
    joined_at = models.DateTimeField(auto_now_add=True)
    is_admin = models.BooleanField(default=False)
    
    class Meta:
        unique_together = ('room', 'user')
    
    def __str__(self):
        return f"{self.user.username} in {self.room}"

class ChatRoomMessage(models.Model):
    """Model for messages in a chat room"""
    room = models.ForeignKey(ChatRoom, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='room_messages_sent')
    message = models.TextField(blank=True)
    image = models.ImageField(upload_to='chat_images/', null=True, blank=True)
    timestamp = models.DateTimeField(default=timezone.now)
    
    def __str__(self):
        return f"Message from {self.sender.username} in {self.room}"
