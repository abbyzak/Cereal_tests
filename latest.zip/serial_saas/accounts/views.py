from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.urls import reverse
from django.utils import timezone

from .forms import CustomUserCreationForm, UserProfileForm
from .models import User
from serial_management.models import SerialNumber, RechargeRequest

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # In a real system, you would send email verification here
            # For simplicity, we'll mark the user as verified right away
            user.email_verified = True
            user.save()
            
            # Log in the user
            login(request, user)
            
            # Redirect to dashboard
            return redirect('accounts:dashboard')
    else:
        form = CustomUserCreationForm()
    
    return render(request, 'accounts/register.html', {'form': form})

@login_required
def dashboard(request):
    # Get active serial number for the user
    active_serial = SerialNumber.objects.filter(
        user=request.user,
        is_active=True,
        expires_at__gt=timezone.now()
    ).first()
    
    # Check if user has a pending recharge request
    pending_recharge = RechargeRequest.objects.filter(
        user=request.user,
        status='pending'
    ).first()
    
    # Check if the user has already used their trial
    has_used_trial = SerialNumber.objects.filter(
        user=request.user,
        is_trial=True
    ).exists()
    
    return render(request, 'accounts/dashboard.html', {
        'active_serial': active_serial,
        'pending_recharge': pending_recharge,
        'has_used_trial': has_used_trial,
    })

@login_required
def profile_settings(request):
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Your profile has been updated successfully.")
            return redirect('profile_settings')
    else:
        form = UserProfileForm(instance=request.user)
    
    return render(request, 'accounts/profile_settings.html', {'form': form})

@login_required
def status(request):
    # Get all user's serial numbers, both active and expired
    serials = SerialNumber.objects.filter(user=request.user).order_by('-activated_at')
    
    # Get the current active serial if any
    active_serial = next((s for s in serials if not s.is_expired()), None)
    
    context = {
        'serials': serials,
        'active_serial': active_serial,
    }
    
    return render(request, 'accounts/status.html', context)

# Add a custom logout view to ensure proper logout functionality
def logout_view(request):
    """
    Custom logout view to ensure proper logout and redirect
    """
    if request.method == 'POST':
        auth_logout(request)
        messages.success(request, 'You have been successfully logged out.')
        return redirect('home')
    # If not POST, redirect to the home page
    return redirect('home')
