from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib import messages
from django.utils import timezone
from django.http import JsonResponse
from django.db import transaction

from .models import SerialNumber, RechargeRequest
from .forms import SerialNumberForm, BulkSerialNumberForm, RechargeApprovalForm, RechargeForm
from accounts.forms import RechargeRequestForm
from accounts.models import User
from core.models import PaymentMethod

@login_required
def recharge(request):
    # Check if user already has an active serial number
    active_serial = SerialNumber.objects.filter(
        user=request.user,
        is_active=True,
        expires_at__gt=timezone.now()
    ).first()
    
    # Check if user has a pending recharge request
    pending_recharge = RechargeRequest.objects.filter(
        user=request.user,
        status='pending'
    ).first()
    
    # Get payment methods from the database
    payment_methods = PaymentMethod.objects.filter(is_active=True).order_by('-is_default', 'name')
    default_payment_method = payment_methods.filter(is_default=True).first() or payment_methods.first()
    
    if request.method == 'POST':
        form = RechargeForm(request.POST)
        if form.is_valid():
            # Create a new recharge request - serial will be auto-generated but UI will show pending
            recharge_request = RechargeRequest(
                user=request.user,
                phone_number=form.cleaned_data['phone_number'],
                status='pending'  # Keep status as pending for UI consistency
            )
            recharge_request.save()
            
            # Check if this is an AJAX request (via fetch)
            is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest' or 'application/json' in request.headers.get('Accept', '')
            
            if is_ajax:
                # For AJAX requests, just return the current page
                # The JavaScript will handle displaying payment methods
                return render(request, 'serial_management/recharge.html', {
                    'form': form,
                    'active_serial': active_serial,
                    'pending_recharge': recharge_request,  # Use the newly created request
                    'payment_methods': payment_methods,
                    'default_payment_method': default_payment_method,
                    'show_payment': True
                })
            else:
                # For regular form submissions, redirect to recharge_status
                messages.success(
                    request, 
                    f"Your recharge request has been received. Please follow the payment instructions to complete your purchase."
                )
                return redirect('recharge_status')
    else:
        # Pre-fill phone number if the user has one
        initial_data = {}
        if request.user.phone_number:
            initial_data['phone_number'] = request.user.phone_number
        form = RechargeForm(initial=initial_data)
    
    # Check if we should show payment methods (e.g., after form submission)
    show_payment = request.GET.get('payment') == 'show' or pending_recharge is not None
    
    context = {
        'form': form,
        'active_serial': active_serial,
        'pending_recharge': pending_recharge,
        'payment_methods': payment_methods,
        'default_payment_method': default_payment_method,
        'show_payment': show_payment
    }
    
    return render(request, 'serial_management/recharge.html', context)

@login_required
def recharge_status(request):
    # Get all recharge requests for the user
    recharge_requests = RechargeRequest.objects.filter(user=request.user).order_by('-requested_at')
    
    # Get pending recharge request if any
    pending_request = recharge_requests.filter(status='pending').first()
    
    # Get payment methods for displaying instructions
    payment_methods = PaymentMethod.objects.filter(is_active=True).order_by('-is_default', 'name')
    default_payment_method = payment_methods.filter(is_default=True).first() or payment_methods.first()
    
    context = {
        'recharge_requests': recharge_requests,
        'pending_request': pending_request,
        'payment_methods': payment_methods,
        'default_payment_method': default_payment_method,
    }
    
    return render(request, 'serial_management/recharge_status.html', context)

@staff_member_required
def admin_dashboard(request):
    # Get counts for dashboard
    serial_count = SerialNumber.objects.count()
    available_serial_count = SerialNumber.objects.filter(user__isnull=True, is_active=False).count()
    pending_recharge_count = RechargeRequest.objects.filter(status='pending').count()
    active_serial_count = SerialNumber.objects.filter(is_active=True, expires_at__gt=timezone.now()).count()
    
    context = {
        'serial_count': serial_count,
        'available_serial_count': available_serial_count,
        'pending_recharge_count': pending_recharge_count,
        'active_serial_count': active_serial_count,
    }
    
    return render(request, 'serial_management/admin_dashboard.html', context)

@staff_member_required
def serial_number_management(request):
    if request.method == 'POST':
        form = SerialNumberForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Serial number created successfully!")
            return redirect('serial_number_management')
    else:
        form = SerialNumberForm()
    
    bulk_form = BulkSerialNumberForm()
    
    # Get all serial numbers with pagination
    serials = SerialNumber.objects.all().order_by('-created_at')
    
    context = {
        'form': form,
        'bulk_form': bulk_form,
        'serials': serials,
    }
    
    return render(request, 'serial_management/serial_management.html', context)

@staff_member_required
def bulk_serial_creation(request):
    if request.method == 'POST':
        form = BulkSerialNumberForm(request.POST)
        if form.is_valid():
            serials = form.cleaned_data['serial_numbers']
            
            # Create serial numbers
            SerialNumber.objects.bulk_create([
                SerialNumber(code=code) for code in serials
            ])
            
            messages.success(request, f"Successfully created {len(serials)} serial numbers.")
            return redirect('serial_number_management')
    else:
        form = BulkSerialNumberForm()
    
    return render(request, 'serial_management/bulk_serial_creation.html', {'form': form})

@staff_member_required
def pending_recharges(request):
    # Get all pending recharge requests
    pending_requests = RechargeRequest.objects.filter(status='pending').order_by('requested_at')
    
    context = {
        'pending_requests': pending_requests,
    }
    
    return render(request, 'serial_management/pending_recharges.html', context)

@staff_member_required
def approve_recharge(request, request_id):
    recharge_request = get_object_or_404(RechargeRequest, id=request_id, status='pending')
    
    if request.method == 'POST':
        form = RechargeApprovalForm(request.POST)
        if form.is_valid():
            # For backward compatibility, check if we need to provide a serial or use the auto-generated one
            serial_number = form.cleaned_data['serial_number']
            if not recharge_request.assigned_serial:
                serial_number = form.cleaned_data['serial_number']
            else:
                # Use the existing auto-generated serial
                serial_number = recharge_request.assigned_serial
            
            # This just updates the UI status now
            recharge_request.approve(request.user, serial_number)
            
            messages.success(request, f"Recharge request approved and serial number {serial_number.code} assigned.")
            return redirect('pending_recharges')
    else:
        form = RechargeApprovalForm()
    
    context = {
        'form': form,
        'recharge_request': recharge_request,
    }
    
    return render(request, 'serial_management/approve_recharge.html', context)

@staff_member_required
def reject_recharge(request, request_id):
    recharge_request = get_object_or_404(RechargeRequest, id=request_id, status='pending')
    
    # Reject the request
    recharge_request.reject(request.user)
    
    messages.success(request, f"Recharge request from {recharge_request.user.username} has been rejected.")
    return redirect('pending_recharges')

@staff_member_required
def activate_trial(request):
    """
    View for activating a trial period for a user.
    Creates a new serial number and assigns it to the specified user.
    """
    if request.method == 'POST':
        username = request.POST.get('username')
        try:
            user = User.objects.get(username=username)
            
            # Create a new serial number
            serials = SerialNumber.generate_serial_numbers(1)
            if serials:
                serial = serials[0]
                # Activate for the user
                serial.activate(user)
                
                messages.success(request, f"Trial activated for {username}. Serial: {serial.code}")
            else:
                messages.error(request, "Failed to generate serial number.")
                
        except User.DoesNotExist:
            messages.error(request, f"User {username} does not exist.")
        
        return redirect('admin_dashboard')
        
    # GET request - show form
    return render(request, 'serial_management/activate_trial.html')
