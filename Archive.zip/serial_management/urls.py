from django.urls import path
from . import views

urlpatterns = [
    # Client-facing URLs
    path('recharge/', views.recharge, name='recharge'),
    path('recharge-status/', views.recharge_status, name='recharge_status'),
    
    # Admin URLs
    path('admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin/serials/', views.serial_number_management, name='serial_number_management'),
    path('admin/serials/bulk/', views.bulk_serial_creation, name='bulk_serial_creation'),
    path('admin/recharges/', views.pending_recharges, name='pending_recharges'),
    path('admin/recharges/approve/<int:request_id>/', views.approve_recharge, name='approve_recharge'),
    path('admin/recharges/reject/<int:request_id>/', views.reject_recharge, name='reject_recharge'),
] 