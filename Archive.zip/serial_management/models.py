from django.db import models
from django.utils import timezone
from accounts.models import User
import math
from django.utils.crypto import get_random_string

class SerialNumber(models.Model):
    code = models.CharField(max_length=50, unique=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='serial_numbers', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    activated_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=False)
    exe_hash = models.CharField(max_length=100, null=True, blank=True, help_text="Hash of the executable that first validated this serial")
    first_validated_at = models.DateTimeField(null=True, blank=True, help_text="When this serial was first validated")
    
    def __str__(self):
        return f"{self.code} - {self.user.username if self.user else 'Unassigned'}"
    
    def activate(self, user):
        """
        Activate a serial number for a user.
        """
        if self.user is not None and self.user != user:
            raise ValueError(f"Serial number already assigned to {self.user}")
        
        self.user = user
        self.is_active = True
        self.activated_at = timezone.now()
        
        # All serials have 3-day validity
        self.expires_at = self.activated_at + timezone.timedelta(days=3)
        
        self.save()
        return self
    
    def is_expired(self):
        """Check if serial number has expired"""
        if not self.expires_at:
            return True
        return timezone.now() > self.expires_at
    
    def time_remaining(self):
        """Return remaining time in hours"""
        if not self.expires_at or self.is_expired():
            return 0
        remaining = self.expires_at - timezone.now()
        return max(0, remaining.total_seconds() / 3600)
        
    def time_remaining_seconds(self):
        """Return remaining time in seconds for precise countdown"""
        if not self.expires_at or self.is_expired():
            return 0
        remaining = self.expires_at - timezone.now()
        return max(0, remaining.total_seconds())
    
    def time_remaining_display(self):
        """Return formatted time remaining for display (HH:MM:SS)"""
        seconds = self.time_remaining_seconds()
        if seconds <= 0:
            return "00:00:00"
            
        hours = math.floor(seconds / 3600)
        minutes = math.floor((seconds % 3600) / 60)
        seconds = math.floor(seconds % 60)
        
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    
    def time_remaining_percent(self):
        """Return percentage of time remaining (for progress bars)"""
        if not self.activated_at or not self.expires_at:
            return 0
            
        total_duration = (self.expires_at - self.activated_at).total_seconds()
        if total_duration <= 0:
            return 0
            
        remaining = self.time_remaining_seconds()
        percentage = (remaining / total_duration) * 100
        return min(100, max(0, percentage))
    
    @classmethod
    def generate_serial_numbers(cls, count=1):
        """
        Generate random serial numbers with 3-day validity and save them to the database.
        """
        serials = []
        for _ in range(count):
            serial = cls.objects.create(
                code=cls.generate_code(),
            )
            serials.append(serial)
        return serials

    @classmethod
    def generate_trial_serials(cls, count=50):
        """
        Generate multiple trial serial numbers (3-day validity) at once.
        Default is to generate 50 serials.
        """
        return cls.generate_serial_numbers(count)

    @classmethod
    def generate_code(cls):
        """
        Generate a unique serial code.
        """
        # Loop until we generate a unique code
        while True:
            code = f"SN-{get_random_string(length=12, allowed_chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')}"
            if not cls.objects.filter(code=code).exists():
                return code

class RechargeRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='recharge_requests')
    phone_number = models.CharField(max_length=15)
    requested_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    processed_at = models.DateTimeField(null=True, blank=True)
    processed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, 
                                    related_name='processed_recharges')
    assigned_serial = models.ForeignKey(SerialNumber, on_delete=models.SET_NULL, null=True, blank=True)
    
    # Hidden field to track if a serial has been silently generated
    # This won't be visible in the UI but lets us track if the serial is actually ready
    has_auto_generated_serial = models.BooleanField(default=False, editable=False)
    
    def __str__(self):
        return f"{self.user.username} - {self.status} - {self.requested_at.strftime('%Y-%m-%d %H:%M')}"
    
    def save(self, *args, **kwargs):
        is_new = self.pk is None  # Check if this is a new request
        
        # First save to get an ID
        super().save(*args, **kwargs)
        
        # For new requests, silently generate a serial in the background
        if is_new and not self.has_auto_generated_serial:
            # Generate a new serial number
            serials = SerialNumber.generate_serial_numbers(1)
            if serials:
                serial = serials[0]
                
                # Activate the serial for the user
                serial.activate(self.user)
                
                # Assign the serial but keep status as pending for UI purposes
                self.assigned_serial = serial
                self.has_auto_generated_serial = True
                
                # Only update these fields without triggering the full save again
                update_fields = ['assigned_serial', 'has_auto_generated_serial']
                if update_fields:
                    self._skip_hooks = True  # Avoid recursive save
                    super().save(update_fields=update_fields)
                    self._skip_hooks = False
    
    def approve(self, admin_user, serial_number=None):
        """
        Approve recharge request. This is now just for UI purposes since 
        the serial is actually already generated and assigned.
        """
        self.status = 'approved'
        self.processed_at = timezone.now()
        self.processed_by = admin_user
        
        # If no serial_number is provided, keep the auto-generated one
        if serial_number and not self.assigned_serial:
            self.assigned_serial = serial_number
            
            # Activate the serial number for the user
            serial_number.activate(self.user)
        
        self.save()
        
    def reject(self, admin_user):
        """Reject recharge request"""
        self.status = 'rejected'
        self.processed_at = timezone.now()
        self.processed_by = admin_user
        self.save()

class SerialCheckIn(models.Model):
    serial_number = models.ForeignKey(SerialNumber, on_delete=models.CASCADE, related_name='check_ins')
    check_in_time = models.DateTimeField(auto_now_add=True)
    device_id = models.CharField(max_length=100, blank=True, null=True)
    
    def __str__(self):
        return f"{self.serial_number.code} - {self.check_in_time.strftime('%Y-%m-%d %H:%M')}"
    
    class Meta:
        ordering = ['-check_in_time']
