from django.contrib import admin
from django.urls import path, reverse
from django.shortcuts import redirect, render
from django.template.response import TemplateResponse
from django.contrib import messages
from django import forms
from django.utils.html import format_html
from .models import SerialNumber, RechargeRequest, SerialCheckIn
from django.utils import timezone
from datetime import timedelta
from django.http import HttpResponseRedirect

class BulkSerialForm(forms.Form):
    """Form for generating multiple serial numbers"""
    count = forms.IntegerField(min_value=1, max_value=1000, 
                              label="Number of 3-day serials to generate", 
                              initial=50)

class SerialNumberAdmin(admin.ModelAdmin):
    list_display = ('code', 'created_at', 'expires_at', 'is_active', 'user')
    list_filter = ('is_active', 'created_at')
    search_fields = ('code', 'user__username')
    readonly_fields = ('code', 'created_at', 'expires_at', 'is_active', 'user')
    
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('generate/', self.generate_serials_view, name='serial_management_serialnumber_generate_serials'),
            path('generate/5/', self.generate_5_serials, name='serial_management_serialnumber_generate_5'),
            path('generate/20/', self.generate_20_serials, name='serial_management_serialnumber_generate_20'),
            path('generate/50/', self.generate_50_serials, name='serial_management_serialnumber_generate_50'),
            path('generate-50-trial-serials/', self.generate_50_trial_serials, name='generate-50-trial-serials'),
        ]
        return custom_urls + urls
    
    def generate_serials_view(self, request):
        if request.method == 'POST':
            try:
                count = int(request.POST.get('count', 0))
                if count > 0:
                    serials = self.generate_serials(count)
                    messages.success(request, f'Successfully generated {count} serial numbers with 3-day validity.')
                else:
                    messages.error(request, 'Please enter a valid number greater than 0.')
            except ValueError:
                messages.error(request, 'Please enter a valid number.')
            return HttpResponseRedirect(reverse('admin:serial_management_serialnumber_changelist'))
        
        return TemplateResponse(request, 'admin/serial_management/serialnumber/generate_serials.html')
    
    def generate_serials(self, count):
        return SerialNumber.generate_serial_numbers(count)
    
    def generate_5_serials(self, request):
        self.generate_serials(5)
        messages.success(request, 'Successfully generated 5 serial numbers with 3-day validity.')
        return HttpResponseRedirect(reverse('admin:serial_management_serialnumber_changelist'))
    
    def generate_20_serials(self, request):
        self.generate_serials(20)
        messages.success(request, 'Successfully generated 20 serial numbers with 3-day validity.')
        return HttpResponseRedirect(reverse('admin:serial_management_serialnumber_changelist'))
    
    def generate_50_serials(self, request):
        self.generate_serials(50)
        messages.success(request, 'Successfully generated 50 serial numbers with 3-day validity.')
        return HttpResponseRedirect(reverse('admin:serial_management_serialnumber_changelist'))
        
    def generate_50_trial_serials(self, request):
        """Generate 50 trial serials with 3-day validity"""
        serials = SerialNumber.generate_trial_serials(50)
        messages.success(request, 'Successfully generated 50 trial serial numbers with 3-day validity.')
        return HttpResponseRedirect(reverse('admin:serial_management_serialnumber_changelist'))

class RechargeRequestAdmin(admin.ModelAdmin):
    list_display = ['user', 'phone_number', 'status', 'requested_at', 'processed_at', 'action_buttons']
    list_filter = ['status', 'requested_at', 'processed_at']
    search_fields = ['user__username', 'user__email', 'phone_number']
    readonly_fields = ['requested_at', 'processed_at', 'processed_by']
    
    def action_buttons(self, obj):
        """Generate action buttons for each request"""
        # Only show buttons for pending requests
        if obj.status != 'pending':
            return f"{obj.status.title()} by {obj.processed_by}"
            
        # Generate the action buttons
        approve_url = reverse('admin:approve_recharge', args=[obj.pk])
        reject_url = reverse('admin:reject_recharge', args=[obj.pk])
        
        return format_html(
            '<a class="button" href="{}">Approve</a>&nbsp;'
            '<a class="button" href="{}">Reject</a>',
            approve_url, reject_url
        )
    action_buttons.short_description = 'Actions'
    action_buttons.allow_tags = True
    
    def get_urls(self):
        urls = super().get_urls()
        my_urls = [
            path('<int:request_id>/approve/', self.admin_site.admin_view(self.approve_recharge), name='approve_recharge'),
            path('<int:request_id>/reject/', self.admin_site.admin_view(self.reject_recharge), name='reject_recharge'),
        ]
        return my_urls + urls
        
    def approve_recharge(self, request, request_id):
        """Approve a recharge request"""
        recharge_request = RechargeRequest.objects.get(id=request_id)
        
        # Don't process already processed requests
        if recharge_request.status != 'pending':
            self.message_user(request, f"This request has already been {recharge_request.status}.")
            return redirect('admin:serial_management_rechargerequest_changelist')
        
        # Generate a new serial number
        serials = SerialNumber.generate_serial_numbers(1)
        if not serials:
            self.message_user(request, "Failed to generate serial number.", messages.ERROR)
            return redirect('admin:serial_management_rechargerequest_changelist')
            
        # Approve the request
        recharge_request.approve(request.user, serials[0])
        
        self.message_user(request, f"Successfully approved recharge request and assigned serial {serials[0].code}.")
        return redirect('admin:serial_management_rechargerequest_changelist')
        
    def reject_recharge(self, request, request_id):
        """Reject a recharge request"""
        recharge_request = RechargeRequest.objects.get(id=request_id)
        
        # Don't process already processed requests
        if recharge_request.status != 'pending':
            self.message_user(request, f"This request has already been {recharge_request.status}.")
            return redirect('admin:serial_management_rechargerequest_changelist')
            
        # Reject the request
        recharge_request.reject(request.user)
        
        self.message_user(request, f"Successfully rejected recharge request.")
        return redirect('admin:serial_management_rechargerequest_changelist')

class SerialCheckInAdmin(admin.ModelAdmin):
    list_display = ('serial_number', 'check_in_time', 'device_id')
    list_filter = ('check_in_time',)
    search_fields = ('serial_number__code', 'device_id')
    readonly_fields = ('serial_number', 'check_in_time', 'device_id')

admin.site.register(SerialNumber, SerialNumberAdmin)
admin.site.register(RechargeRequest, RechargeRequestAdmin)
admin.site.register(SerialCheckIn, SerialCheckInAdmin)
