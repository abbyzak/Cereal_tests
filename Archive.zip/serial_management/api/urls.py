from django.urls import path
from . import views

urlpatterns = [
    path('serial/', views.SerialNumberAPIView.as_view(), name='api_serial_active'),
    path('serial/history/', views.SerialNumberHistoryAPIView.as_view(), name='api_serial_history'),
    path('recharge/', views.RechargeRequestCreateAPIView.as_view(), name='api_recharge_create'),
    path('recharge/status/', views.RechargeRequestStatusAPIView.as_view(), name='api_recharge_status'),
    path('validate/', views.ValidateSerialAPIView.as_view(), name='api_validate_serial'),
] 