# Chatroom API Documentation

This document provides detailed information on how to interact with the Serial SaaS Chatroom API using a Node.js client.

## Base URL

All API endpoints are relative to your server's base URL. For example:

```
https://your-server.com/friends/api/chatroom/
```

## Authentication

The API supports both authenticated and anonymous users. For authenticated users, include your authentication token in the request headers:

```javascript
const headers = {
  'Authorization': 'Token YOUR_AUTH_TOKEN',
  'Content-Type': 'application/json'
};
```

## API Endpoints

### 1. Create a Chatroom

**Endpoint:** `POST /friends/api/chatroom/create/`

**Request Body:**
```json
{
  "name": "My Chatroom"
}
```

**Response:**
```json
{
  "room_id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "My Chatroom",
  "created_at": "2023-06-15T12:00:00Z",
  "is_active": true
}
```

**Node.js Example:**
```javascript
const axios = require('axios');

async function createChatroom(name) {
  try {
    const response = await axios.post('https://your-server.com/friends/api/chatroom/create/', {
      name: name
    }, {
      headers: {
        'Authorization': 'Token YOUR_AUTH_TOKEN',
        'Content-Type': 'application/json'
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Error creating chatroom:', error.response.data);
    throw error;
  }
}
```

### 2. Join a Chatroom

**Endpoint:** `POST /friends/api/chatroom/{room_id}/join/`

**Response:**
```json
{
  "success": true,
  "room_id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "My Chatroom",
  "joined_at": "2023-06-15T12:30:00Z"
}
```

**Node.js Example:**
```javascript
async function joinChatroom(roomId) {
  try {
    const response = await axios.post(`https://your-server.com/friends/api/chatroom/${roomId}/join/`, {}, {
      headers: {
        'Authorization': 'Token YOUR_AUTH_TOKEN',
        'Content-Type': 'application/json'
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Error joining chatroom:', error.response.data);
    throw error;
  }
}
```

### 3. Get Chatroom Messages

**Endpoint:** `GET /friends/api/chatroom/{room_id}/messages/`

**Query Parameters:**
- `limit` (optional): Number of messages to retrieve (default: 50, max: 100)

**Response:**
```json
{
  "room_id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "My Chatroom",
  "messages": [
    {
      "id": 123,
      "sender_id": 456,
      "sender_username": "user123",
      "message": "Hello, everyone!",
      "image_url": null,
      "timestamp": "2023-06-15T12:35:00Z"
    },
    {
      "id": 124,
      "sender_id": 789,
      "sender_username": "user456",
      "message": "Hi there!",
      "image_url": null,
      "timestamp": "2023-06-15T12:36:00Z"
    }
  ],
  "messages_count": 2
}
```

**Node.js Example:**
```javascript
async function getChatroomMessages(roomId, limit = 50) {
  try {
    const response = await axios.get(`https://your-server.com/friends/api/chatroom/${roomId}/messages/`, {
      params: { limit },
      headers: {
        'Authorization': 'Token YOUR_AUTH_TOKEN',
        'Content-Type': 'application/json'
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Error getting chatroom messages:', error.response.data);
    throw error;
  }
}
```

### 4. Send a Message to a Chatroom

**Endpoint:** `POST /friends/api/chatroom/{room_id}/send/`

**Request Body:**
```json
{
  "message": "Hello, this is my message!"
}
```

**For sending an image:**
```javascript
// Using FormData for multipart/form-data
const formData = new FormData();
formData.append('message', 'Check out this image!');
formData.append('image', fs.createReadStream('path/to/image.jpg'));
```

**Response:**
```json
{
  "id": 125,
  "room_id": "550e8400-e29b-41d4-a716-446655440000",
  "sender_id": 456,
  "sender_username": "user123",
  "message": "Hello, this is my message!",
  "image_url": null,
  "timestamp": "2023-06-15T12:40:00Z"
}
```

**Node.js Example (Text Message):**
```javascript
async function sendTextMessage(roomId, message) {
  try {
    const response = await axios.post(`https://your-server.com/friends/api/chatroom/${roomId}/send/`, {
      message: message
    }, {
      headers: {
        'Authorization': 'Token YOUR_AUTH_TOKEN',
        'Content-Type': 'application/json'
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Error sending message:', error.response.data);
    throw error;
  }
}
```

**Node.js Example (Image Message):**
```javascript
const FormData = require('form-data');
const fs = require('fs');

async function sendImageMessage(roomId, message, imagePath) {
  try {
    const formData = new FormData();
    formData.append('message', message);
    formData.append('image', fs.createReadStream(imagePath));
    
    const response = await axios.post(`https://your-server.com/friends/api/chatroom/${roomId}/send/`, formData, {
      headers: {
        'Authorization': 'Token YOUR_AUTH_TOKEN',
        ...formData.getHeaders()
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Error sending image message:', error.response.data);
    throw error;
  }
}
```

## Real-time Chat Implementation

For a real-time chat experience, you can implement polling to fetch new messages at regular intervals:

```javascript
class ChatroomClient {
  constructor(roomId, authToken) {
    this.roomId = roomId;
    this.authToken = authToken;
    this.lastMessageCount = 0;
    this.pollingInterval = null;
    this.messageHandlers = [];
  }
  
  // Start polling for new messages
  startPolling(intervalMs = 3000) {
    this.pollingInterval = setInterval(() => this.fetchNewMessages(), intervalMs);
  }
  
  // Stop polling
  stopPolling() {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
  }
  
  // Fetch new messages
  async fetchNewMessages() {
    try {
      const response = await axios.get(`https://your-server.com/friends/api/chatroom/${this.roomId}/messages/`, {
        headers: {
          'Authorization': `Token ${this.authToken}`,
          'Content-Type': 'application/json'
        }
      });
      
      const { messages } = response.data;
      
      // Check if there are new messages
      if (messages.length > this.lastMessageCount) {
        // Get only the new messages
        const newMessages = messages.slice(this.lastMessageCount);
        
        // Update the message count
        this.lastMessageCount = messages.length;
        
        // Notify all handlers
        this.messageHandlers.forEach(handler => handler(newMessages));
      }
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  }
  
  // Send a text message
  async sendMessage(message) {
    return await sendTextMessage(this.roomId, message);
  }
  
  // Send an image message
  async sendImage(message, imagePath) {
    return await sendImageMessage(this.roomId, message, imagePath);
  }
  
  // Register a handler for new messages
  onNewMessage(handler) {
    this.messageHandlers.push(handler);
  }
  
  // Remove a handler
  removeMessageHandler(handler) {
    this.messageHandlers = this.messageHandlers.filter(h => h !== handler);
  }
}

// Usage example
async function main() {
  const roomId = '550e8400-e29b-41d4-a716-446655440000';
  const authToken = 'YOUR_AUTH_TOKEN';
  
  // Create a chatroom client
  const chatroom = new ChatroomClient(roomId, authToken);
  
  // Register a handler for new messages
  chatroom.onNewMessage(messages => {
    messages.forEach(message => {
      console.log(`${message.sender_username}: ${message.message}`);
    });
  });
  
  // Start polling for new messages
  chatroom.startPolling();
  
  // Send a message
  await chatroom.sendMessage('Hello, everyone!');
  
  // Keep the process running
  process.on('SIGINT', () => {
    chatroom.stopPolling();
    process.exit();
  });
}

main().catch(console.error);
```

## Error Handling

The API returns appropriate HTTP status codes and error messages:

- `400 Bad Request`: Invalid input data
- `401 Unauthorized`: Authentication required
- `403 Forbidden`: Permission denied
- `404 Not Found`: Resource not found
- `500 Internal Server Error`: Server error

Example error response:
```json
{
  "error": "Message text or image is required."
}
```

## Best Practices

1. **Polling Frequency**: For a chat application, a polling interval of 3-5 seconds is recommended to balance responsiveness and server load.

2. **Error Handling**: Always implement proper error handling to gracefully handle network issues or server errors.

3. **Authentication**: Store authentication tokens securely and refresh them when needed.

4. **Message Formatting**: When displaying messages, properly escape HTML content to prevent XSS attacks.

5. **Offline Support**: Consider implementing a local message queue for offline support, with messages sent when the connection is restored.

6. **Rate Limiting**: Be mindful of API rate limits and implement appropriate backoff strategies.

7. **Image Optimization**: When sending images, consider compressing them to reduce bandwidth usage.

## Conclusion

This API provides a simple yet powerful way to implement chatroom functionality in your applications. By following these guidelines and best practices, you can create a robust and user-friendly chat experience. 