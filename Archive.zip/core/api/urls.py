from django.urls import path
from . import views

urlpatterns = [
    path('faq/', views.FAQListAPIView.as_view(), name='api_faq_list'),
    path('downloads/', views.ApplicationBinaryListAPIView.as_view(), name='api_downloads_list'),
] 