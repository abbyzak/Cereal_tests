from django.shortcuts import render
from django.contrib.auth.decorators import login_required
import json
from django.conf import settings
import os

from .models import FAQ, ApplicationBinary

def home(request):
    """Home page with product overview and CTA buttons"""
    return render(request, 'core/home.html')

def pricing(request):
    """Pricing page showing the cost of service"""
    return render(request, 'core/pricing.html')

def downloads(request):
    """Downloads page with binaries sorted by platform"""
    windows_binaries = ApplicationBinary.objects.filter(platform='windows').order_by('-version')
    macos_binaries = ApplicationBinary.objects.filter(platform='macos').order_by('-version')
    linux_binaries = ApplicationBinary.objects.filter(platform='linux').order_by('-version')
    
    context = {
        'windows_binaries': windows_binaries,
        'macos_binaries': macos_binaries,
        'linux_binaries': linux_binaries,
        'latest_windows': windows_binaries.filter(is_latest=True).first(),
        'latest_macos': macos_binaries.filter(is_latest=True).first(),
        'latest_linux': linux_binaries.filter(is_latest=True).first(),
    }
    
    return render(request, 'core/downloads.html', context)

def faq(request):
    """FAQ page with categorized questions and answers"""
    faqs_by_category = {}
    categories = FAQ.CATEGORY_CHOICES
    
    for category_code, category_name in categories:
        faqs_by_category[category_name] = FAQ.objects.filter(category=category_code)
    
    context = {
        'faqs_by_category': faqs_by_category,
        'categories': [name for _, name in categories],
    }
    
    return render(request, 'core/faq.html', context)

def demo(request):
    """Demo page with embedded video content loaded from JSON files"""
    # Path to the static JSON files in the file system
    demo_videos_json_path = os.path.join(settings.STATIC_ROOT, 'data/demo_yt_demo.json')
    tutorial_videos_json_path = os.path.join(settings.STATIC_ROOT, 'data/tutorial_videos.json')
    
    # URLs for client-side loading
    demo_videos_json_url = os.path.join(settings.STATIC_URL, 'data/demo_yt_demo.json')
    tutorial_videos_json_url = os.path.join(settings.STATIC_URL, 'data/tutorial_videos.json')
    
    # We'll provide both the JSON URLs for client-side loading 
    # and the direct file paths for backend loading if needed
    context = {
        'demo_videos_json': demo_videos_json_url,
        'tutorial_videos_json': tutorial_videos_json_url
    }
    
    return render(request, 'core/demo.html', context)

def websocket_test(request):
    """
    Render the WebSocket test page.
    """
    return render(request, 'core/websocket_test.html')

def about_developer(request):
    """About the developer page with profile information"""
    return render(request, 'core/about_developer.html')
