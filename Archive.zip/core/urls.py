from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('pricing/', views.pricing, name='pricing'),
    path('downloads/', views.downloads, name='downloads'),
    path('faq/', views.faq, name='faq'),
    path('demo/', views.demo, name='demo'),
    path('ws-test/', views.websocket_test, name='websocket_test'),
] 