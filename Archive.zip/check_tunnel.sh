#!/bin/bash

# Get container ID of the cloudflared container
CLOUDFLARED_CONTAINER=$(docker-compose -f docker-compose.prod.yml ps -q cloudflared)

if [ -z "$CLOUDFLARED_CONTAINER" ]; then
    echo "Cloudflared container is not running!"
    exit 1
fi

echo "===== Cloudflared Container Info ====="
docker inspect $CLOUDFLARED_CONTAINER | grep -A 5 "Command"

echo "===== Cloudflared Tunnel Status ====="
docker exec $CLOUDFLARED_CONTAINER cloudflared tunnel info

echo "===== Checking Tunnel Routing ====="
docker exec $CLOUDFLARED_CONTAINER cloudflared tunnel route ip show

echo "===== Cloudflared Logs ====="
docker logs --tail 30 $CLOUDFLARED_CONTAINER 