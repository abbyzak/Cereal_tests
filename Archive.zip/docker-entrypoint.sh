#!/bin/bash

# Exit on error
set -e

# Wait for database to be ready
echo "Waiting for PostgreSQL..."
while ! nc -z db 5432; do
  sleep 0.1
done
echo "PostgreSQL started"

# Apply database migrations
echo "Applying database migrations..."
python manage.py migrate

# Create superuser
echo "Creating superuser..."
python create_superuser.py

# Collect static files
echo "Collecting static files..."
python manage.py collectstatic --noinput

# Remove all .pyc files
find . -name "*.pyc" -delete

# Start server
echo "Starting server..."
if [ "$DJANGO_PRODUCTION" = "True" ]; then
  echo "Running in production mode..."
  gunicorn serial_saas_project.wsgi:application --bind 0.0.0.0:8000
else
  echo "Running in development mode..."
  python manage.py runserver 0.0.0.0:8000
fi 