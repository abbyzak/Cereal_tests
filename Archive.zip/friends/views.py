from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.http import JsonResponse, HttpResponse
from django.db.models import Q
from django.urls import reverse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
import logging
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from django.contrib.auth import get_user_model

from serial_management.models import SerialNumber, RechargeRequest
from accounts.models import User
from .models import FriendCode, ChatMessage, ChatRoom, ChatRoomParticipant, ChatRoomMessage
import datetime
from .serializers import ChatMessageSerializer

logger = logging.getLogger(__name__)

User = get_user_model()

@login_required
def help_friend(request):
    """
    View for helping a friend by sharing some of your serial time with them.
    """
    # Get active serial number for the user
    active_serial = SerialNumber.objects.filter(
        user=request.user,
        is_active=True,
        expires_at__gt=timezone.now()
    ).first()
    
    # Get any active friend codes the user has created
    active_codes = FriendCode.objects.filter(
        creator=request.user,
        is_used=False,
        expires_at__gt=timezone.now()
    ).order_by('-created_at')
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        # Generate a friend code
        if action == 'generate_code':
            time_to_share = request.POST.get('time_to_share')
            
            try:
                # Validate time to share
                time_hours = float(time_to_share)
                if time_hours <= 0:
                    messages.error(request, "Please enter a positive amount of time to share.")
                    return render(request, 'friends/help_friend.html', {
                        'active_serial': active_serial,
                        'active_codes': active_codes
                    })
                
                if not active_serial:
                    messages.error(request, "You don't have an active serial to share from.")
                    return render(request, 'friends/help_friend.html', {
                        'active_serial': active_serial,
                        'active_codes': active_codes
                    })
                
                # Calculate time remaining and check if user has enough to share
                time_remaining = (active_serial.expires_at - timezone.now()).total_seconds() / 3600  # hours
                
                if time_hours > time_remaining - 1:  # Keep at least 1 hour for the user
                    messages.error(request, f"You can only share up to {time_remaining - 1:.1f} hours.")
                    return render(request, 'friends/help_friend.html', {
                        'active_serial': active_serial,
                        'active_codes': active_codes
                    })
                
                # Generate a new friend code
                code = FriendCode.generate_code()
                
                # Create the friend code object
                expires_in_days = 7  # Friend codes expire after 7 days if not used
                friend_code = FriendCode.objects.create(
                    code=code,
                    creator=request.user,
                    hours_offered=time_hours,
                    expires_at=timezone.now() + datetime.timedelta(days=expires_in_days)
                )
                
                messages.success(
                    request, 
                    f"Friend code generated successfully! Share this code with your friend: {code}"
                )
                
                # Refresh the active codes
                active_codes = FriendCode.objects.filter(
                    creator=request.user,
                    is_used=False,
                    expires_at__gt=timezone.now()
                ).order_by('-created_at')
                
                return render(request, 'friends/help_friend.html', {
                    'active_serial': active_serial,
                    'active_codes': active_codes,
                    'new_code': friend_code
                })
                
            except Exception as e:
                messages.error(request, f"An error occurred: {str(e)}")
        
        # Direct sharing with email
        elif action == 'direct_share':
            friend_email = request.POST.get('friend_email')
            time_to_share = request.POST.get('time_to_share')
            
            try:
                # Validate inputs
                if not friend_email:
                    messages.error(request, "Please enter your friend's email address.")
                    return render(request, 'friends/help_friend.html', {
                        'active_serial': active_serial,
                        'active_codes': active_codes
                    })
                
                # Check if friend exists in our system
                friend = User.objects.filter(email=friend_email).first()
                if not friend:
                    messages.error(request, "We couldn't find a user with that email address.")
                    return render(request, 'friends/help_friend.html', {
                        'active_serial': active_serial,
                        'active_codes': active_codes
                    })
                
                # Check if user is trying to share with themselves
                if friend.id == request.user.id:
                    messages.error(request, "You can't share credits with yourself.")
                    return render(request, 'friends/help_friend.html', {
                        'active_serial': active_serial,
                        'active_codes': active_codes
                    })
                
                # Validate time to share
                time_hours = float(time_to_share)
                if time_hours <= 0:
                    messages.error(request, "Please enter a positive amount of time to share.")
                    return render(request, 'friends/help_friend.html', {
                        'active_serial': active_serial,
                        'active_codes': active_codes
                    })
                
                if not active_serial:
                    messages.error(request, "You don't have an active serial to share from.")
                    return render(request, 'friends/help_friend.html', {
                        'active_serial': active_serial,
                        'active_codes': active_codes
                    })
                
                # Calculate time remaining and check if user has enough to share
                time_remaining = (active_serial.expires_at - timezone.now()).total_seconds() / 3600  # hours
                
                if time_hours > time_remaining - 1:  # Keep at least 1 hour for the user
                    messages.error(request, f"You can only share up to {time_remaining - 1:.1f} hours.")
                    return render(request, 'friends/help_friend.html', {
                        'active_serial': active_serial,
                        'active_codes': active_codes
                    })
                
                # Share time with friend
                # 1. Reduce current user's time
                active_serial.expires_at = active_serial.expires_at - datetime.timedelta(hours=time_hours)
                active_serial.save()
                
                # 2. Find or create a serial for the friend
                friend_serial = SerialNumber.objects.filter(
                    user=friend,
                    is_active=True,
                    expires_at__gt=timezone.now()
                ).first()
                
                if friend_serial:
                    # Add time to friend's existing serial
                    friend_serial.expires_at = friend_serial.expires_at + datetime.timedelta(hours=time_hours)
                    friend_serial.save()
                else:
                    # Create a new serial for the friend with the shared time
                    # This would be better handled by a SerialNumber manager method in a real app
                    # For now, we'll just copy some code from the activate_trial view
                    
                    # Find an available serial
                    available_serial = SerialNumber.objects.filter(
                        user__isnull=True,
                        is_active=False,
                        is_trial=False  # Don't use trial serials
                    ).first()
                    
                    if not available_serial:
                        messages.error(request, "No available serials to allocate to your friend. Please contact the administrator.")
                        return render(request, 'friends/help_friend.html', {
                            'active_serial': active_serial,
                            'active_codes': active_codes
                        })
                    
                    # Activate the serial for the friend
                    available_serial.user = friend
                    available_serial.is_active = True
                    available_serial.activated_at = timezone.now()
                    
                    # Set expiration based on shared time
                    available_serial.expires_at = timezone.now() + datetime.timedelta(hours=time_hours)
                    available_serial.save()
                
                messages.success(
                    request, 
                    f"Successfully shared {time_hours} hours with {friend.username}. Your new expiry time is {active_serial.expires_at.strftime('%Y-%m-%d %H:%M')}."
                )
                
                # Refresh page data
                active_serial = SerialNumber.objects.filter(
                    user=request.user,
                    is_active=True,
                    expires_at__gt=timezone.now()
                ).first()
                
                return render(request, 'friends/help_friend.html', {
                    'active_serial': active_serial,
                    'active_codes': active_codes,
                    'shared_with': friend
                })
                
            except Exception as e:
                messages.error(request, f"An error occurred: {str(e)}")
    
    # For GET request
    return render(request, 'friends/help_friend.html', {
        'active_serial': active_serial,
        'active_codes': active_codes
    })

@login_required
def redeem_code(request):
    """
    View for redeeming a friend code.
    """
    if request.method == 'POST':
        code = request.POST.get('code', '').strip()
        
        if not code:
            messages.error(request, "Please enter a valid friend code.")
            return redirect('friends:redeem_code')
        
        try:
            # Check if the code exists and is valid
            friend_code = FriendCode.objects.filter(
                code=code,
                is_used=False,
                expires_at__gt=timezone.now()
            ).first()
            
            if not friend_code:
                messages.error(request, "Invalid or expired friend code.")
                return redirect('friends:redeem_code')
            
            # Check if the user is trying to redeem their own code
            if friend_code.creator == request.user:
                messages.error(request, "You cannot redeem your own code.")
                return redirect('friends:redeem_code')
            
            # Get the hours offered
            hours_offered = friend_code.hours_offered
            
            # Check if the creator still has an active serial
            creator_serial = SerialNumber.objects.filter(
                user=friend_code.creator,
                is_active=True,
                expires_at__gt=timezone.now()
            ).first()
            
            if not creator_serial:
                messages.error(request, "The code creator no longer has an active serial. This code cannot be redeemed.")
                return redirect('friends:redeem_code')
            
            # Calculate time remaining for the creator
            creator_time_remaining = (creator_serial.expires_at - timezone.now()).total_seconds() / 3600  # hours
            
            # Make sure the creator still has enough time
            if hours_offered > creator_time_remaining - 1:  # Keep at least 1 hour for the creator
                # If they don't have enough time, adjust the hours offered
                hours_offered = max(0, creator_time_remaining - 1)
                
                if hours_offered <= 0:
                    messages.error(request, "The code creator does not have enough time left to share.")
                    return redirect('friends:redeem_code')
                
                messages.info(request, f"The code creator has less time available now. You will receive {hours_offered:.1f} hours instead.")
            
            # Reduce creator's time
            creator_serial.expires_at = creator_serial.expires_at - datetime.timedelta(hours=hours_offered)
            creator_serial.save()
            
            # Find or create a serial for the current user
            user_serial = SerialNumber.objects.filter(
                user=request.user,
                is_active=True,
                expires_at__gt=timezone.now()
            ).first()
            
            if user_serial:
                # Add time to user's existing serial
                user_serial.expires_at = user_serial.expires_at + datetime.timedelta(hours=hours_offered)
                user_serial.save()
            else:
                # Find an available serial
                available_serial = SerialNumber.objects.filter(
                    user__isnull=True,
                    is_active=False,
                    is_trial=False
                ).first()
                
                if not available_serial:
                    messages.error(request, "No available serials to allocate. Please contact the administrator.")
                    return redirect('friends:redeem_code')
                
                # Activate the serial for the user
                available_serial.user = request.user
                available_serial.is_active = True
                available_serial.activated_at = timezone.now()
                available_serial.expires_at = timezone.now() + datetime.timedelta(hours=hours_offered)
                available_serial.save()
                
                user_serial = available_serial
            
            # Mark the code as used
            friend_code.is_used = True
            friend_code.used_by = request.user
            friend_code.used_at = timezone.now()
            friend_code.save()
            
            messages.success(
                request, 
                f"Successfully redeemed code for {hours_offered:.1f} hours! Your serial now expires at {user_serial.expires_at.strftime('%Y-%m-%d %H:%M')}."
            )
            
            return redirect('dashboard')
            
        except Exception as e:
            messages.error(request, f"An error occurred: {str(e)}")
            return redirect('friends:redeem_code')
    
    return render(request, 'friends/redeem_code.html')

@login_required
def chat_list(request):
    """
    View for displaying the list of users the current user has chatted with
    and chatrooms they participate in.
    """
    # Get user's chatrooms
    user_chatrooms = ChatRoomParticipant.objects.filter(user=request.user)
    chatrooms_data = []
    
    for participant in user_chatrooms:
        room = participant.room
        # Count messages in the chatroom
        message_count = ChatRoomMessage.objects.filter(room=room).count()
        # Count participants
        participant_count = ChatRoomParticipant.objects.filter(room=room).count()
        
        # Add chatroom data
        chatrooms_data.append({
            'room': room,
            'message_count': message_count,
            'participant_count': participant_count,
            'is_admin': participant.is_admin,
            'joined_at': participant.joined_at
        })
    
    return render(request, 'friends/chat_list.html', {
        'chatrooms': chatrooms_data
    })

@login_required
def chat_room(request, user_id):
    """
    View for the chat room with a specific user.
    """
    # Get the chat partner
    chat_partner = get_object_or_404(User, id=user_id)
    
    # Don't allow chatting with yourself
    if chat_partner.id == request.user.id:
        messages.error(request, "You can't chat with yourself.")
        return redirect('friends:chat_list')
    
    # Create a unique chat code for this conversation
    user_ids = sorted([str(request.user.id), str(chat_partner.id)])
    chat_code = f"CHAT_{user_ids[0]}_{user_ids[1]}"
    
    # Handle POST request for message submission
    if request.method == 'POST':
        message_text = request.POST.get('message', '').strip()
        image = request.FILES.get('image')
        
        # Check if either message or image is provided
        if message_text or image:
            # Save the message
            try:
                ChatMessage.objects.create(
                    sender=request.user,
                    recipient=chat_partner,
                    message=message_text,
                    image=image,
                    is_read=False
                )
                logger.info(f"Message saved via HTTP POST: from {request.user.id} to {chat_partner.id}")
            except Exception as e:
                logger.error(f"Error saving message via HTTP POST: {str(e)}")
                messages.error(request, "Failed to send your message. Please try again.")
        
        # Redirect to avoid resubmission on refresh
        return redirect('friends:chat_room', user_id=user_id)
    
    # Get the conversation history (most recent 50 messages)
    messages_query = ChatMessage.objects.filter(
        (Q(sender=request.user) & Q(recipient=chat_partner)) |
        (Q(sender=chat_partner) & Q(recipient=request.user))
    ).order_by('-timestamp')[:50]
    
    # Reverse to show oldest first
    chat_messages = reversed(messages_query)
    
    # Mark all messages from the partner as read
    ChatMessage.objects.filter(
        sender=chat_partner,
        recipient=request.user,
        is_read=False
    ).update(is_read=True)
    
    return render(request, 'friends/chat_room.html', {
        'chat_partner': chat_partner,
        'chat_messages': chat_messages,
        'chat_code': chat_code
    })

@login_required
@require_POST
def revoke_code(request, code_id):
    """
    View for revoking a friend code.
    """
    # Get the code
    friend_code = get_object_or_404(FriendCode, id=code_id, creator=request.user)
    
    if friend_code.is_used:
        messages.error(request, "Cannot revoke a code that has already been used.")
        return redirect('friends:help_friend')
    
    # Delete the code
    friend_code.delete()
    
    messages.success(request, "Friend code has been revoked successfully.")
    return redirect('friends:help_friend')

@login_required
def generate_code(request):
    """
    API endpoint for generating a friend code.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'Only POST method is allowed'}, status=405)
    
    time_to_share = request.POST.get('time_to_share')
    
    try:
        # Validate time to share
        time_hours = float(time_to_share)
        if time_hours <= 0:
            return JsonResponse({'error': 'Please enter a positive amount of time to share.'}, status=400)
        
        # Get active serial number for the user
        active_serial = SerialNumber.objects.filter(
            user=request.user,
            is_active=True,
            expires_at__gt=timezone.now()
        ).first()
        
        if not active_serial:
            return JsonResponse({'error': "You don't have an active serial to share from."}, status=400)
        
        # Calculate time remaining and check if user has enough to share
        time_remaining = (active_serial.expires_at - timezone.now()).total_seconds() / 3600  # hours
        
        if time_hours > time_remaining - 1:  # Keep at least 1 hour for the user
            return JsonResponse({'error': f"You can only share up to {time_remaining - 1:.1f} hours."}, status=400)
        
        # Generate a new friend code
        code = FriendCode.generate_code()
        
        # Create the friend code object
        expires_in_days = 7  # Friend codes expire after 7 days if not used
        friend_code = FriendCode.objects.create(
            code=code,
            creator=request.user,
            hours_offered=time_hours,
            expires_at=timezone.now() + datetime.timedelta(days=expires_in_days)
        )
        
        return JsonResponse({
            'success': True,
            'code': code,
            'hours_offered': time_hours,
            'expires_at': friend_code.expires_at.isoformat()
        })
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def share_direct(request):
    """
    API endpoint for directly sharing time with a friend via email.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'Only POST method is allowed'}, status=405)
    
    friend_email = request.POST.get('friend_email')
    time_to_share = request.POST.get('time_to_share')
    
    try:
        # Validate inputs
        if not friend_email:
            return JsonResponse({'error': "Please enter your friend's email address."}, status=400)
        
        # Check if friend exists in our system
        friend = User.objects.filter(email=friend_email).first()
        if not friend:
            return JsonResponse({'error': "We couldn't find a user with that email address."}, status=400)
        
        # Check if user is trying to share with themselves
        if friend.id == request.user.id:
            return JsonResponse({'error': "You can't share credits with yourself."}, status=400)
        
        # Validate time to share
        time_hours = float(time_to_share)
        if time_hours <= 0:
            return JsonResponse({'error': "Please enter a positive amount of time to share."}, status=400)
        
        # Get active serial number for the user
        active_serial = SerialNumber.objects.filter(
            user=request.user,
            is_active=True,
            expires_at__gt=timezone.now()
        ).first()
        
        if not active_serial:
            return JsonResponse({'error': "You don't have an active serial to share from."}, status=400)
        
        # Calculate time remaining and check if user has enough to share
        time_remaining = (active_serial.expires_at - timezone.now()).total_seconds() / 3600  # hours
        
        if time_hours > time_remaining - 1:  # Keep at least 1 hour for the user
            return JsonResponse({'error': f"You can only share up to {time_remaining - 1:.1f} hours."}, status=400)
        
        # Share time with friend
        # 1. Reduce current user's time
        active_serial.expires_at = active_serial.expires_at - datetime.timedelta(hours=time_hours)
        active_serial.save()
        
        # 2. Find or create a serial for the friend
        friend_serial = SerialNumber.objects.filter(
            user=friend,
            is_active=True,
            expires_at__gt=timezone.now()
        ).first()
        
        if friend_serial:
            # Add time to friend's existing serial
            friend_serial.expires_at = friend_serial.expires_at + datetime.timedelta(hours=time_hours)
            friend_serial.save()
            new_expiry = friend_serial.expires_at
        else:
            # Find an available serial
            available_serial = SerialNumber.objects.filter(
                user__isnull=True,
                is_active=False,
                is_trial=False
            ).first()
            
            if not available_serial:
                return JsonResponse({'error': "No available serials to allocate to your friend. Please contact the administrator."}, status=400)
            
            # Activate the serial for the friend
            available_serial.user = friend
            available_serial.is_active = True
            available_serial.activated_at = timezone.now()
            available_serial.expires_at = timezone.now() + datetime.timedelta(hours=time_hours)
            available_serial.save()
            new_expiry = available_serial.expires_at
        
        return JsonResponse({
            'success': True,
            'friend_username': friend.username,
            'hours_shared': time_hours,
            'your_new_expiry': active_serial.expires_at.isoformat(),
            'friend_expiry': new_expiry.isoformat()
        })
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def process_redeem_code(request):
    """
    API endpoint for redeeming a friend code.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'Only POST method is allowed'}, status=405)
    
    code = request.POST.get('code', '').strip()
    
    if not code:
        return JsonResponse({'error': "Please enter a valid friend code."}, status=400)
    
    try:
        # Check if the code exists and is valid
        friend_code = FriendCode.objects.filter(
            code=code,
            is_used=False,
            expires_at__gt=timezone.now()
        ).first()
        
        if not friend_code:
            return JsonResponse({'error': "Invalid or expired friend code."}, status=400)
        
        # Check if the user is trying to redeem their own code
        if friend_code.creator == request.user:
            return JsonResponse({'error': "You cannot redeem your own code."}, status=400)
        
        # Get the hours offered
        hours_offered = friend_code.hours_offered
        
        # Check if the creator still has an active serial
        creator_serial = SerialNumber.objects.filter(
            user=friend_code.creator,
            is_active=True,
            expires_at__gt=timezone.now()
        ).first()
        
        if not creator_serial:
            return JsonResponse({'error': "The code creator no longer has an active serial. This code cannot be redeemed."}, status=400)
        
        # Calculate time remaining for the creator
        creator_time_remaining = (creator_serial.expires_at - timezone.now()).total_seconds() / 3600  # hours
        
        # Make sure the creator still has enough time
        if hours_offered > creator_time_remaining - 1:  # Keep at least 1 hour for the creator
            # If they don't have enough time, adjust the hours offered
            hours_offered = max(0, creator_time_remaining - 1)
        
        # Reduce creator's time
        creator_serial.expires_at = creator_serial.expires_at - datetime.timedelta(hours=hours_offered)
        creator_serial.save()
        
        # Find or create a serial for the current user
        user_serial = SerialNumber.objects.filter(
            user=request.user,
            is_active=True,
            expires_at__gt=timezone.now()
        ).first()
        
        if user_serial:
            # Add time to user's existing serial
            user_serial.expires_at = user_serial.expires_at + datetime.timedelta(hours=hours_offered)
            user_serial.save()
        else:
            # Find an available serial
            available_serial = SerialNumber.objects.filter(
                user__isnull=True,
                is_active=False,
                is_trial=False
            ).first()
            
            if not available_serial:
                return JsonResponse({'error': "No available serials to allocate. Please contact the administrator."}, status=400)
            
            # Activate the serial for the user
            available_serial.user = request.user
            available_serial.is_active = True
            available_serial.activated_at = timezone.now()
            available_serial.expires_at = timezone.now() + datetime.timedelta(hours=hours_offered)
            available_serial.save()
            
            user_serial = available_serial
        
        # Mark the code as used
        friend_code.is_used = True
        friend_code.used_by = request.user
        friend_code.used_at = timezone.now()
        friend_code.save()
        
        return JsonResponse({
            'success': True,
            'hours_received': hours_offered,
            'new_expiry': user_serial.expires_at.isoformat(),
            'creator_username': friend_code.creator.username
        })
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def create_chat_code(request):
    """
    View for creating a shareable chat code.
    """
    # Generate a unique chat code for this user
    chat_code = f"CHAT_{request.user.id}_{timezone.now().strftime('%Y%m%d%H%M%S')}"
    
    if request.method == 'POST':
        # Store the chat code (we could save this to a model if needed for persistence)
        request.session['created_chat_code'] = chat_code
        messages.success(request, f"Chat code created successfully: {chat_code}")
        
        return render(request, 'friends/create_chat_code.html', {
            'chat_code': chat_code
        })
    
    return render(request, 'friends/create_chat_code.html')

@login_required
def join_chat(request):
    """
    View for joining a chat using a code.
    """
    if request.method == 'POST':
        chat_code = request.POST.get('chat_code', '').strip()
        
        if not chat_code or not chat_code.startswith('CHAT_'):
            messages.error(request, "Please enter a valid chat code.")
            return render(request, 'friends/join_chat.html')
        
        # Extract the user ID from the chat code
        try:
            # Format: CHAT_USER_ID_TIMESTAMP
            parts = chat_code.split('_')
            if len(parts) < 3:
                raise ValueError("Invalid chat code format")
            
            user_id = int(parts[1])
            
            # Check if the user exists
            chat_creator = get_object_or_404(User, id=user_id)
            
            # Redirect to the chat room with that user
            return redirect('friends:chat_by_code', chat_code=chat_code)
            
        except (ValueError, User.DoesNotExist) as e:
            messages.error(request, "Invalid chat code or user not found.")
            return render(request, 'friends/join_chat.html')
    
    return render(request, 'friends/join_chat.html')

@login_required
def chat_by_code(request, chat_code):
    """
    View for chat room accessed by code.
    """
    try:
        # Parse the chat code to get the user ID
        parts = chat_code.split('_')
        user_id = int(parts[1])
        
        # Get the chat partner
        chat_partner = get_object_or_404(User, id=user_id)
        
        # Don't allow chatting with yourself
        if chat_partner.id == request.user.id:
            messages.error(request, "You can't chat with yourself.")
            return redirect('friends:chat_list')
        
        # Handle POST request for message submission
        if request.method == 'POST':
            message_text = request.POST.get('message', '').strip()
            image = request.FILES.get('image')
            
            # Check if either message or image is provided
            if message_text or image:
                # Save the message
                try:
                    ChatMessage.objects.create(
                        sender=request.user,
                        recipient=chat_partner,
                        message=message_text,
                        image=image,
                        is_read=False
                    )
                    logger.info(f"Message saved via HTTP POST (by code): from {request.user.id} to {chat_partner.id}")
                except Exception as e:
                    logger.error(f"Error saving message via HTTP POST (by code): {str(e)}")
                    messages.error(request, "Failed to send your message. Please try again.")
            
            # Redirect to avoid resubmission on refresh
            return redirect('friends:chat_by_code', chat_code=chat_code)
        
        # Get the conversation history
        messages_query = ChatMessage.objects.filter(
            (Q(sender=request.user) & Q(recipient=chat_partner)) |
            (Q(sender=chat_partner) & Q(recipient=request.user))
        ).order_by('-timestamp')[:50]
        
        # Reverse to show oldest first
        chat_messages = reversed(messages_query)
        
        # Mark all messages from the partner as read
        ChatMessage.objects.filter(
            sender=chat_partner,
            recipient=request.user,
            is_read=False
        ).update(is_read=True)
        
        return render(request, 'friends/chat_room.html', {
            'chat_partner': chat_partner,
            'chat_messages': chat_messages,
            'chat_code': chat_code,
            'joined_by_code': True
        })
        
    except (ValueError, IndexError, User.DoesNotExist):
        messages.error(request, "Invalid chat code or user not found.")
        return redirect('friends:chat_list')

class ChatMessageViewSet(viewsets.ModelViewSet):
    serializer_class = ChatMessageSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        return ChatMessage.objects.filter(
            Q(sender=user) | Q(recipient=user)
        ).order_by('-timestamp')

    def perform_create(self, serializer):
        serializer.save(sender=self.request.user)

    @action(detail=False, methods=['get'])
    def conversation(self, request):
        other_user_id = request.query_params.get('user_id')
        if not other_user_id:
            return Response(
                {'error': 'user_id parameter is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        messages = ChatMessage.objects.filter(
            (Q(sender=request.user) & Q(recipient_id=other_user_id)) |
            (Q(sender_id=other_user_id) & Q(recipient=request.user))
        ).order_by('-timestamp')
        
        serializer = self.get_serializer(messages, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def unread(self, request):
        messages = ChatMessage.objects.filter(
            recipient=request.user,
            is_read=False
        ).order_by('-timestamp')
        
        serializer = self.get_serializer(messages, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['post'])
    def mark_read(self, request):
        other_user_id = request.data.get('user_id')
        if not other_user_id:
            return Response(
                {'error': 'user_id parameter is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        messages = ChatMessage.objects.filter(
            sender_id=other_user_id,
            recipient=request.user,
            is_read=False
        )
        messages.update(is_read=True)
        
        return Response({'status': 'messages marked as read'})

@api_view(['GET'])
@permission_classes([AllowAny])
def api_chat_messages(request, user_id):
    """
    API endpoint to get chat messages with a specific user.
    Returns JSON response with messages.
    """
    try:
        chat_partner = User.objects.get(id=user_id)
        
        # Use anonymous user if not authenticated
        user = request.user if request.user.is_authenticated else User.objects.get(id=1)  # Default to user ID 1
        
        # Get the conversation history (most recent 50 messages)
        messages_query = ChatMessage.objects.filter(
            (Q(sender=user) & Q(recipient=chat_partner)) |
            (Q(sender=chat_partner) & Q(recipient=user))
        ).order_by('-timestamp')[:50]
        
        # Convert messages to JSON format
        messages_data = []
        for msg in messages_query:
            messages_data.append({
                'id': msg.id,
                'sender_id': msg.sender.id,
                'recipient_id': msg.recipient.id,
                'message': msg.message,
                'image_url': msg.image.url if msg.image else None,
                'timestamp': msg.timestamp.isoformat(),
                'is_read': msg.is_read
            })
        
        # Mark messages as read if user is authenticated
        if user.is_authenticated:
            ChatMessage.objects.filter(
                sender=chat_partner,
                recipient=user,
                is_read=False
            ).update(is_read=True)
        
        return Response({
            'messages': messages_data,
            'chat_partner': {
                'id': chat_partner.id,
                'username': chat_partner.username
            }
        })
        
    except User.DoesNotExist:
        return Response(
            {"error": "User not found."},
            status=status.HTTP_404_NOT_FOUND
        )
    except Exception as e:
        return Response(
            {"error": str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['POST'])
@permission_classes([AllowAny])
def api_send_message(request, user_id):
    """
    API endpoint to send a message to a specific user.
    Accepts JSON with message text and optional image.
    """
    try:
        chat_partner = User.objects.get(id=user_id)
        
        # Get message data from request
        message_text = request.data.get('message', '').strip()
        image = request.FILES.get('image')
        
        # Check if either message or image is provided
        if not message_text and not image:
            return Response(
                {"error": "Message text or image is required."},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Use anonymous user if not authenticated
        sender = request.user if request.user.is_authenticated else User.objects.get(id=1)  # Default to user ID 1
        
        # Save the message
        chat_message = ChatMessage.objects.create(
            sender=sender,
            recipient=chat_partner,
            message=message_text,
            image=image,
            is_read=False
        )
        
        # Return the created message
        return Response({
            'id': chat_message.id,
            'sender_id': chat_message.sender.id,
            'recipient_id': chat_message.recipient.id,
            'message': chat_message.message,
            'image_url': chat_message.image.url if chat_message.image else None,
            'timestamp': chat_message.timestamp.isoformat(),
            'is_read': chat_message.is_read
        }, status=status.HTTP_201_CREATED)
        
    except User.DoesNotExist:
        return Response(
            {"error": "User not found."},
            status=status.HTTP_404_NOT_FOUND
        )
    except Exception as e:
        return Response(
            {"error": str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['GET'])
@permission_classes([AllowAny])
def api_unread_messages(request):
    """
    API endpoint to get all unread messages for the current user.
    """
    try:
        # Use anonymous user if not authenticated
        user = request.user if request.user.is_authenticated else User.objects.get(id=1)  # Default to user ID 1
        
        unread_messages = ChatMessage.objects.filter(
            recipient=user,
            is_read=False
        ).order_by('-timestamp')
        
        messages_data = []
        for msg in unread_messages:
            messages_data.append({
                'id': msg.id,
                'sender_id': msg.sender.id,
                'sender_username': msg.sender.username,
                'message': msg.message,
                'image_url': msg.image.url if msg.image else None,
                'timestamp': msg.timestamp.isoformat()
            })
        
        return Response({
            'unread_count': len(messages_data),
            'messages': messages_data
        })
        
    except Exception as e:
        return Response(
            {"error": str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['POST'])
@permission_classes([AllowAny])
def api_mark_read(request, user_id):
    """
    API endpoint to mark messages from a specific user as read.
    """
    try:
        chat_partner = User.objects.get(id=user_id)
        
        # Use anonymous user if not authenticated
        user = request.user if request.user.is_authenticated else User.objects.get(id=1)  # Default to user ID 1
        
        # Mark messages as read
        updated_count = ChatMessage.objects.filter(
            sender=chat_partner,
            recipient=user,
            is_read=False
        ).update(is_read=True)
        
        return Response({
            'marked_read_count': updated_count
        })
        
    except User.DoesNotExist:
        return Response(
            {"error": "User not found."},
            status=status.HTTP_404_NOT_FOUND
        )
    except Exception as e:
        return Response(
            {"error": str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

# Chatroom API Endpoints
@api_view(['POST'])
@permission_classes([AllowAny])
def api_create_chatroom(request):
    """
    API endpoint to create a new chat room.
    Returns the room details including the unique room ID.
    """
    try:
        # Use anonymous user if not authenticated
        user = request.user if request.user.is_authenticated else User.objects.get(id=1)
        
        name = request.data.get('name', '')
        
        # Create the room
        room = ChatRoom.objects.create(
            name=name,
            created_by=user
        )
        
        # Add creator as admin participant
        ChatRoomParticipant.objects.create(
            room=room,
            user=user,
            is_admin=True
        )
        
        return Response({
            'room_id': str(room.room_id),
            'name': room.name,
            'created_by': {
                'id': user.id,
                'username': user.username
            },
            'join_url': f"/friends/api/chatroom/{room.room_id}/join/"
        }, status=status.HTTP_201_CREATED)
        
    except Exception as e:
        return Response(
            {"error": str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['GET'])
@permission_classes([AllowAny])
def api_get_chatroom(request, room_id):
    """
    API endpoint to get chatroom details.
    """
    try:
        room = get_object_or_404(ChatRoom, room_id=room_id, is_active=True)
        
        # Get participants
        participants = ChatRoomParticipant.objects.filter(room=room)
        participants_data = []
        
        for participant in participants:
            participants_data.append({
                'id': participant.user.id,
                'username': participant.user.username,
                'is_admin': participant.is_admin,
                'joined_at': participant.joined_at.isoformat()
            })
        
        return Response({
            'room_id': str(room.room_id),
            'name': room.name,
            'created_by': {
                'id': room.created_by.id,
                'username': room.created_by.username
            },
            'created_at': room.created_at.isoformat(),
            'participants': participants_data,
            'participants_count': len(participants_data)
        })
        
    except Exception as e:
        return Response(
            {"error": str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['POST'])
@permission_classes([AllowAny])
def api_join_chatroom(request, room_id):
    """
    API endpoint to join a chatroom.
    """
    try:
        room = get_object_or_404(ChatRoom, room_id=room_id, is_active=True)
        
        # Use anonymous user if not authenticated
        user = request.user if request.user.is_authenticated else User.objects.get(id=1)
        
        # Add user as participant if not already a participant
        participant, created = ChatRoomParticipant.objects.get_or_create(
            room=room,
            user=user,
            defaults={'is_admin': False}
        )
        
        # Get all participants
        participants = ChatRoomParticipant.objects.filter(room=room)
        participants_data = []
        
        for p in participants:
            participants_data.append({
                'id': p.user.id,
                'username': p.user.username,
                'is_admin': p.is_admin
            })
        
        return Response({
            'room_id': str(room.room_id),
            'name': room.name,
            'joined': created,  # True if newly joined, False if already a participant
            'participants': participants_data,
            'participants_count': len(participants_data)
        })
        
    except Exception as e:
        return Response(
            {"error": str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

# CORS preflight handler for API endpoints
@csrf_exempt
def cors_preflight(request):
    if request.method == 'OPTIONS':
        response = HttpResponse()
        response["Access-Control-Allow-Origin"] = "*"
        response["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        response["Access-Control-Allow-Headers"] = "Origin, Content-Type, Accept, Authorization"
        response["Access-Control-Max-Age"] = "86400"  # 24 hours
        return response
    return None

# Helper function to add CORS headers
def add_cors_headers(response):
    response["Access-Control-Allow-Origin"] = "*"
    response["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    response["Access-Control-Allow-Headers"] = "Origin, Content-Type, Accept, Authorization"
    return response

# Apply CORS preflight handling to API views
@api_view(['GET', 'OPTIONS'])
@permission_classes([AllowAny])
@csrf_exempt
def api_get_room_messages(request, room_id):
    """
    API endpoint to get chatroom messages.
    """
    # Handle OPTIONS request
    if request.method == 'OPTIONS':
        return cors_preflight(request)
        
    try:
        room = get_object_or_404(ChatRoom, room_id=room_id)
        
        # Get messages ordered by timestamp
        messages = ChatRoomMessage.objects.filter(room=room).order_by('-timestamp')[:50]
        
        # Prepare the response data
        messages_data = []
        for msg in messages:
            messages_data.append({
                'id': msg.id,
                'sender_id': msg.sender.id,
                'sender_username': msg.sender.username,
                'message': msg.message,
                'image_url': msg.image.url if msg.image else None,
                'timestamp': msg.timestamp.isoformat()
            })
        
        response = Response({
            'room_id': str(room.room_id),
            'name': room.name,
            'messages': messages_data,
            'messages_count': len(messages_data)
        })
        
        # Add CORS headers
        response = add_cors_headers(response)
        
        return response
        
    except Exception as e:
        response = Response(
            {"error": str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
        response = add_cors_headers(response)
        return response

@api_view(['POST', 'OPTIONS'])
@permission_classes([AllowAny])
@csrf_exempt
def api_send_room_message(request, room_id):
    """
    API endpoint to send a message to a chatroom.
    """
    # Handle OPTIONS request
    if request.method == 'OPTIONS':
        return cors_preflight(request)
        
    try:
        room = get_object_or_404(ChatRoom, room_id=room_id)
        
        # Use anonymous user if not authenticated
        user = request.user
        if not request.user.is_authenticated:
            # Get or create a default user for anonymous messages
            user, created = User.objects.get_or_create(
                username="AnonymousUser",
                defaults={"email": "anonymous@example.com"}
            )
        
        # Check if user is a participant (join them if not)
        if not ChatRoomParticipant.objects.filter(room=room, user=user).exists():
            ChatRoomParticipant.objects.create(
                room=room,
                user=user,
                is_admin=False
            )
        
        # Get message data from request
        message_text = request.data.get('message', '').strip()
        image = request.FILES.get('image')
        
        # Check if either message or image is provided
        if not message_text and not image:
            response = Response(
                {"error": "Message text or image is required."},
                status=status.HTTP_400_BAD_REQUEST
            )
            response = add_cors_headers(response)
            return response
        
        # Save the message
        chat_message = ChatRoomMessage.objects.create(
            room=room,
            sender=user,
            message=message_text,
            image=image
        )
        
        # Return the created message
        response = Response({
            'id': chat_message.id,
            'room_id': str(room.room_id),
            'sender_id': chat_message.sender.id,
            'sender_username': chat_message.sender.username,
            'message': chat_message.message,
            'image_url': chat_message.image.url if chat_message.image else None,
            'timestamp': chat_message.timestamp.isoformat()
        }, status=status.HTTP_201_CREATED)
        
        # Add CORS headers
        response = add_cors_headers(response)
        
        return response
        
    except Exception as e:
        response = Response(
            {"error": str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
        response = add_cors_headers(response)
        return response

@api_view(['POST', 'OPTIONS'])
@permission_classes([AllowAny])
@csrf_exempt
def join_chatroom_api(request, room_id):
    """
    API endpoint to join a chatroom.
    """
    # Handle OPTIONS request
    if request.method == 'OPTIONS':
        return cors_preflight(request)
        
    try:
        room = get_object_or_404(ChatRoom, room_id=room_id)
        
        # Use anonymous user if not authenticated
        user = request.user
        if not request.user.is_authenticated:
            # Get or create a default user for anonymous users
            user, created = User.objects.get_or_create(
                username="AnonymousUser",
                defaults={"email": "anonymous@example.com"}
            )
        
        # Check if user is already a participant
        participant, created = ChatRoomParticipant.objects.get_or_create(
            room=room,
            user=user,
            defaults={'is_admin': False}
        )
        
        response = Response({
            'room_id': str(room.room_id),
            'name': room.name,
            'joined': created,
            'already_member': not created
        })
        
        # Add CORS headers
        response = add_cors_headers(response)
        
        return response
        
    except Exception as e:
        response = Response(
            {"error": str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
        response = add_cors_headers(response)
        return response

@login_required
def create_chatroom_view(request):
    """
    View for creating a new chatroom.
    """
    if request.method == 'POST':
        room_name = request.POST.get('room_name', '').strip()
        
        # Create the room
        room = ChatRoom.objects.create(
            name=room_name,
            created_by=request.user
        )
        
        # Add creator as admin participant
        ChatRoomParticipant.objects.create(
            room=room,
            user=request.user,
            is_admin=True
        )
        
        messages.success(request, f"Chatroom '{room_name}' created successfully! Share the link with others to invite them.")
        return redirect('friends:chatroom_detail', room_id=room.room_id)
    
    return render(request, 'friends/create_chatroom.html')

@login_required
def join_chatroom_view(request):
    """
    View for joining an existing chatroom by ID.
    """
    if request.method == 'POST':
        room_id = request.POST.get('room_id')
        try:
            # Clean the room_id by removing any URL parts if present
            if '?' in room_id:
                room_id = room_id.split('?')[0]
            if '/' in room_id:
                room_id = room_id.split('/')[-1]
            
            chatroom = ChatRoom.objects.get(room_id=room_id)
            
            # Check if user is already a participant
            if not ChatRoomParticipant.objects.filter(room=chatroom, user=request.user).exists():
                ChatRoomParticipant.objects.create(room=chatroom, user=request.user)
                messages.success(request, f'Successfully joined the chatroom: {chatroom.name}')
            else:
                messages.info(request, f'You are already a member of this chatroom: {chatroom.name}')
            
            return redirect('friends:chatroom_detail', room_id=room_id)
            
        except ChatRoom.DoesNotExist:
            messages.error(request, 'Chatroom not found. Please check the room ID and try again.')
        except ValidationError:
            messages.error(request, 'Invalid room ID format. Please enter a valid UUID.')
    
    return render(request, 'friends/join_chatroom.html')

@login_required
def chatroom_detail(request, room_id):
    """
    View for a specific chatroom.
    """
    # Get the chatroom
    room = get_object_or_404(ChatRoom, room_id=room_id, is_active=True)
    
    # Check if user is a participant or join them automatically
    participant, created = ChatRoomParticipant.objects.get_or_create(
        room=room,
        user=request.user,
        defaults={'is_admin': False}
    )
    
    # Handle POST request for message submission
    if request.method == 'POST':
        message_text = request.POST.get('message', '').strip()
        image = request.FILES.get('image')
        
        # Check if either message or image is provided
        if message_text or image:
            # Save the message
            try:
                ChatRoomMessage.objects.create(
                    room=room,
                    sender=request.user,
                    message=message_text,
                    image=image
                )
                logger.info(f"Chatroom message saved via HTTP POST: room {room_id}, from {request.user.id}")
            except Exception as e:
                logger.error(f"Error saving chatroom message via HTTP POST: {str(e)}")
                messages.error(request, "Failed to send your message. Please try again.")
        
        # Redirect to avoid resubmission on refresh
        return redirect('friends:chatroom_detail', room_id=room_id)
    
    # Get the messages (most recent 50 messages)
    chat_messages = ChatRoomMessage.objects.filter(room=room).order_by('-timestamp')[:50]
    
    # Reverse to show oldest first
    chat_messages = reversed(chat_messages)
    
    # Get participants
    participants = ChatRoomParticipant.objects.filter(room=room)
    
    # Create shareable link
    current_site = request.get_host()
    scheme = request.scheme
    shareable_link = f"{scheme}://{current_site}{reverse('friends:join_chatroom_view')}?room_id={room_id}"
    
    return render(request, 'friends/chatroom_detail.html', {
        'room': room,
        'chat_messages': chat_messages,
        'participants': participants,
        'is_admin': participant.is_admin,
        'shareable_link': shareable_link
    })
