#!/usr/bin/env python3
"""
Simple Serial Number Validation Script
Makes a POST request to validate a serial number with a random string as the exe hash.
"""

import requests
import random
import string
import json

# Constants
API_BASE_URL = "http://localhost:8000"  # Change to your actual API URL
VALIDATE_ENDPOINT = "/api/v1/serial/validate/"

def generate_random_hash(length=32):
    """Generate a random string to use as an exe hash"""
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def validate_serial(serial_code, exe_hash):
    """
    Validate a serial number with the API
    """
    url = f"{API_BASE_URL}{VALIDATE_ENDPOINT}"
    
    payload = {
        "serial_code": serial_code,
        "exe_hash": exe_hash
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    print(f"\nSending request to: {url}")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    
    try:
        response = requests.post(url, json=payload, headers=headers)
        
        # Print raw response for debugging
        print(f"\nStatus Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        
        try:
            # Try to format as JSON for pretty printing
            response_data = response.json()
            print(f"\nResponse Body (JSON):")
            print(json.dumps(response_data, indent=2))
        except:
            # If it's not JSON, print raw text
            print(f"\nResponse Body (Raw):")
            print(response.text)
        
        return response
        
    except requests.exceptions.RequestException as e:
        print(f"\nAPI Connection Error: {e}")
        return None
    except Exception as e:
        print(f"\nUnexpected Error: {e}")
        return None

def main():
    print("Simple Serial Validation Script")
    print("==============================")
    
    # Get the serial number from the user
    serial_code = input("Enter your serial number: ")
    
    # Generate a random hash
    exe_hash = generate_random_hash()
    print(f"Using random exe hash: {exe_hash}")
    
    # Validate the serial number
    validate_serial(serial_code, exe_hash)

if __name__ == "__main__":
    main() 