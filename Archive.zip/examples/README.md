# Serial SaaS Validation Example

This example demonstrates how to validate a trial serial number using the Serial SaaS API.

## Features

- Validates the trial serial "TRIAL-C3MF8OXQT6TG"
- Demonstrates first-time validation and hash registration
- Shows subsequent validations on the same machine
- Simulates validation attempts from different machines
- Handles various error cases

## Setup

1. Install Node.js (if not already installed)
2. Install dependencies:
   ```bash
   npm install
   ```

## Usage

Run the example:
```bash
npm start
```

## Expected Output

The example will show three validation attempts:

1. First validation (registers the exe hash)
2. Second validation (same machine, using stored hash)
3. Third validation (different machine, should fail)

## API Endpoint

The example uses the following endpoint:
- URL: `http://localhost:8000/api/v1/serial/validate/`
- Method: POST
- Content-Type: application/json

## Request Format

```json
{
  "serial_code": "TRIAL-C3MF8OXQT6TG",
  "exe_hash": "generated-hash"
}
```

## Response Format

Success (200 OK):
```json
{
  "id": 1,
  "code": "TRIAL-C3MF8OXQT6TG",
  "user": {
    "id": 1,
    "username": "user123",
    "email": "user@example.com"
  },
  "created_at": "2023-01-01T00:00:00Z",
  "activated_at": "2023-01-01T12:00:00Z",
  "expires_at": "2023-01-02T12:00:00Z",
  "is_active": true,
  "time_remaining": 23.5,
  "is_expired": false,
  "exe_hash": "generated-hash",
  "first_validated_at": "2023-01-01T12:30:00Z",
  "is_hash_registered": true
}
```

## Error Cases

1. Invalid/Inactive Serial (404):
```json
{
  "error": "Invalid or inactive serial number."
}
```

2. Expired Serial (400):
```json
{
  "error": "This serial number has expired."
}
```

3. Hash Mismatch (403):
```json
{
  "error": "This serial number is registered to a different executable."
}
``` 