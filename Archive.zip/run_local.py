#!/usr/bin/env python
"""
Run the Django server with local SQLite settings
"""
import os
import sys
import django
from django.core.management import execute_from_command_line

if __name__ == "__main__":
    # Set the Django settings module to our custom settings
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "serial_saas_project.local_sqlite_settings")
    
    # Make sure Django is properly initialized
    django.setup()
    
    # Start the development server
    sys.argv = ['manage.py', 'runserver', '0.0.0.0:8000']
    execute_from_command_line(sys.argv) 