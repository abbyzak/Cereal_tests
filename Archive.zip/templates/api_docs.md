# Serial SaaS API Documentation

## Serial Number Validation API

### Validate Serial Number

This endpoint validates a serial number and registers the executable hash (unique to each installation). On the first validation call for a serial number, the exe hash is registered. Subsequent validation calls must use the same exe hash, preventing the serial from being used on multiple machines.

**URL**: `/api/v1/serial/validate/`

**Method**: `POST`

**Authentication**: None (Public endpoint)

**Request Body**:

```json
{
  "serial_code": "SN-ABCDEFGHIJKL",
  "exe_hash": "a1b2c3d4e5f6g7h8i9j0"
}
```

| Field | Type | Description |
|-------|------|-------------|
| `serial_code` | String | The serial number code to validate |
| `exe_hash` | String | A unique hash identifying the executable (max 100 chars) |

**Response**:

Success (200 OK):
```json
{
  "id": 1,
  "code": "SN-ABCDEFGHIJKL",
  "user": {
    "id": 1,
    "username": "user123",
    "email": "user@example.com"
  },
  "created_at": "2023-01-01T00:00:00Z",
  "activated_at": "2023-01-01T12:00:00Z",
  "expires_at": "2023-01-02T12:00:00Z",
  "is_active": true,
  "time_remaining": 23.5,
  "is_expired": false,
  "exe_hash": "a1b2c3d4e5f6g7h8i9j0",
  "first_validated_at": "2023-01-01T12:30:00Z",
  "is_hash_registered": true
}
```

**Error Responses**:

Invalid or inactive serial (404 Not Found):
```json
{
  "error": "Invalid or inactive serial number."
}
```

Expired serial (400 Bad Request):
```json
{
  "error": "This serial number has expired."
}
```

Mismatched exe hash (403 Forbidden):
```json
{
  "error": "This serial number is registered to a different executable."
}
```

**Code Example (JavaScript)**:

```javascript
async function validateSerial(serialCode, exeHash) {
  try {
    const response = await fetch('/api/v1/serial/validate/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        serial_code: serialCode,
        exe_hash: exeHash
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Validation failed');
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error validating serial:', error);
    throw error;
  }
}
```

**Code Example (C#)**:

```csharp
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

public class SerialValidator
{
    private readonly HttpClient _client = new HttpClient();
    private const string ApiUrl = "https://yourdomain.com/api/v1/serial/validate/";
    
    public async Task<SerialValidationResult> ValidateSerial(string serialCode, string exeHash)
    {
        var request = new
        {
            serial_code = serialCode,
            exe_hash = exeHash
        };
        
        var content = new StringContent(
            JsonConvert.SerializeObject(request),
            Encoding.UTF8,
            "application/json");
            
        var response = await _client.PostAsync(ApiUrl, content);
        
        if (response.IsSuccessStatusCode)
        {
            var responseContent = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<SerialValidationResult>(responseContent);
        }
        else
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            var error = JsonConvert.DeserializeObject<ErrorResponse>(errorContent);
            throw new Exception(error.Error ?? "Failed to validate serial");
        }
    }
}

public class SerialValidationResult
{
    public int Id { get; set; }
    public string Code { get; set; }
    public UserInfo User { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime ActivatedAt { get; set; }
    public DateTime ExpiresAt { get; set; }
    public bool IsActive { get; set; }
    public double TimeRemaining { get; set; }
    public bool IsExpired { get; set; }
    public string ExeHash { get; set; }
    public DateTime FirstValidatedAt { get; set; }
    public bool IsHashRegistered { get; set; }
}

public class UserInfo
{
    public int Id { get; set; }
    public string Username { get; set; }
    public string Email { get; set; }
}

public class ErrorResponse
{
    public string Error { get; set; }
}
```

## Generating Executable Hash

To generate a unique hash for your executable, you can use various methods:

1. **File Hash**: Calculate a cryptographic hash (MD5, SHA-256) of the executable file
2. **Hardware ID**: Combine hardware identifiers (CPU ID, motherboard serial, etc.)
3. **Installation ID**: Generate a unique ID during installation

Example hash generation in C#:

```csharp
using System;
using System.IO;
using System.Security.Cryptography;
using System.Management;
using System.Text;

public static class HashGenerator
{
    public static string GenerateExeHash()
    {
        // Combine executable hash with hardware identifier
        string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
        string fileHash = CalculateFileHash(exePath);
        string hardwareId = GetHardwareId();
        
        // Combine and hash again
        using (SHA256 sha256 = SHA256.Create())
        {
            byte[] combinedBytes = Encoding.UTF8.GetBytes(fileHash + hardwareId);
            byte[] hashBytes = sha256.ComputeHash(combinedBytes);
            
            // Convert to hex string
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < hashBytes.Length; i++)
            {
                builder.Append(hashBytes[i].ToString("x2"));
            }
            
            return builder.ToString();
        }
    }
    
    private static string CalculateFileHash(string filename)
    {
        using (var md5 = MD5.Create())
        {
            using (var stream = File.OpenRead(filename))
            {
                var hash = md5.ComputeHash(stream);
                return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
            }
        }
    }
    
    private static string GetHardwareId()
    {
        // Get CPU ID
        string cpuId = "";
        ManagementClass mc = new ManagementClass("Win32_Processor");
        ManagementObjectCollection moc = mc.GetInstances();
        foreach (ManagementObject mo in moc)
        {
            cpuId = mo.Properties["ProcessorId"].Value.ToString();
            break;
        }
        
        // Get motherboard serial
        string motherboardSerial = "";
        mc = new ManagementClass("Win32_BaseBoard");
        moc = mc.GetInstances();
        foreach (ManagementObject mo in moc)
        {
            motherboardSerial = mo.Properties["SerialNumber"].Value.ToString();
            break;
        }
        
        return cpuId + motherboardSerial;
    }
}
``` 