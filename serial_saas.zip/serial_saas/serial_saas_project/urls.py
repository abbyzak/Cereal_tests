"""
URL configuration for serial_saas_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from django.contrib.auth import views as auth_views

# Import all the views needed for direct URL access
from accounts.views import logout_view, dashboard, status, profile_settings, register
from serial_management.views import recharge, recharge_status, activate_trial, admin_dashboard
from core.views import downloads, about_developer

schema_view = get_schema_view(
    openapi.Info(
        title="Serial SaaS API",
        default_version='v1',
        description="API for Serial SaaS application",
        terms_of_service="https://www.example.com/terms/",
        contact=openapi.Contact(email="contact@example.com"),
        license=openapi.License(name="MIT License"),
    ),
    public=True,
    permission_classes=[permissions.AllowAny],
)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls', namespace='accounts')),
    path('serial/', include('serial_management.urls')),
    path('friends/', include('friends.urls', namespace='friends')),
    path('', include('core.urls')),
    
    # Auth URLs that need to be accessible without namespace
    path('login/', auth_views.LoginView.as_view(template_name='accounts/login.html'), name='login'),
    path('register/', register, name='register'),
    path('logout/', logout_view, name='logout'),
    path('dashboard/', dashboard, name='dashboard'),
    path('status/', status, name='status'),
    path('profile-settings/', profile_settings, name='profile_settings'),
    
    # Serial management URLs that need to be accessible without namespace
    path('recharge/', recharge, name='recharge'),
    path('recharge-status/', recharge_status, name='recharge_status'),
    path('activate-trial/', activate_trial, name='activate_trial'),
    path('admin-dashboard/', admin_dashboard, name='admin_dashboard'),
    
    # Core URLs that need to be accessible without namespace
    path('downloads/', downloads, name='downloads'),
    path('about-developer/', about_developer, name='about_developer'),
    
    # API URLs
    path('api/v1/', include('serial_saas_project.api_urls')),
    
    # API Documentation
    path('api/docs/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
    path('api/swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
# Add media URL for all environments to ensure images are always served
else:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
