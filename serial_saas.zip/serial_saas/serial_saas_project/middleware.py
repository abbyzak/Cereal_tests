from django.utils.deprecation import MiddlewareMixin
from django.middleware.csrf import get_token

class CSRFRefreshMiddleware(MiddlewareMixin):
    """
    Middleware to ensure CSRF token is refreshed on every request to avoid token expiration issues.
    This helps prevent 'CSRF token from POST incorrect' errors after sessions expire or users use the back button.
    """
    def process_request(self, request):
        """Get CSRF token for the request to refresh it"""
        get_token(request)
        return None 