"""
Local SQLite settings that override the main settings.
"""
import os
from pathlib import Path

# Import all settings from the main settings file
from .settings import *

# Force SQLite database regardless of environment variables
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Use debug mode to simplify local development
DEBUG = True

# Ensure better error handling
ADMINS = [('Admin', 'admin@example.com')]

# Static files settings - use basic setup since we're in debug mode
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_STORAGE = 'django.contrib.staticfiles.storage.StaticFilesStorage'

# Add localhost to CSRF trusted origins
CSRF_TRUSTED_ORIGINS.append('http://localhost:8000')
CSRF_TRUSTED_ORIGINS.append('http://127.0.0.1:8000')

# Update the trusted origins to include HTTP
for origin in list(CSRF_TRUSTED_ORIGINS):
    if origin.startswith('https://'):
        http_origin = 'http://' + origin[8:]
        if http_origin not in CSRF_TRUSTED_ORIGINS:
            CSRF_TRUSTED_ORIGINS.append(http_origin) 