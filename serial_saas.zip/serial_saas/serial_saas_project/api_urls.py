from django.urls import path, include

urlpatterns = [
    path('accounts/', include('accounts.api.urls')),
    path('serial/', include('serial_management.api.urls')),
    path('core/', include('core.api.urls')),
] 