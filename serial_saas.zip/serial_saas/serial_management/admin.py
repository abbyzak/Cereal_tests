from django.contrib import admin
from django.urls import path, reverse
from django.shortcuts import redirect, render
from django.template.response import TemplateResponse
from django.contrib import messages
from django import forms
from django.utils.html import format_html
from .models import SerialNumber, RechargeRequest

class BulkTrialSerialForm(forms.Form):
    """Form for generating bulk trial serials."""
    count = forms.IntegerField(
        min_value=1, 
        max_value=100, 
        initial=10,
        label="Number of trial serials to generate",
        help_text="Generate between 1 and 100 trial serial numbers at once"
    )

@admin.register(SerialNumber)
class SerialNumberAdmin(admin.ModelAdmin):
    list_display = ('code', 'user', 'is_active', 'is_trial', 'created_at', 'activated_at', 'expires_at')
    list_filter = ('is_active', 'is_trial', 'created_at', 'activated_at')
    search_fields = ('code', 'user__username', 'user__email')
    readonly_fields = ('created_at',)
    actions = ['generate_trial_serials', 'cancel_trial_serials']
    change_list_template = 'admin/serial_management/serialnumber/change_list.html'
    
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('generate-trials/', self.admin_site.admin_view(self.generate_trials_view), name='generate-trial-serials'),
            path('generate-5-trials/', self.admin_site.admin_view(self.generate_5_trials), name='generate-5-trial-serials'),
            path('generate-20-trials/', self.admin_site.admin_view(self.generate_20_trials), name='generate-20-trial-serials'),
            path('generate-50-trials/', self.admin_site.admin_view(self.generate_50_trials), name='generate-50-trial-serials'),
        ]
        return custom_urls + urls
    
    def generate_trials_view(self, request):
        """View for generating a custom number of trial serials."""
        if request.method == 'POST':
            form = BulkTrialSerialForm(request.POST)
            if form.is_valid():
                count = form.cleaned_data['count']
                serials = SerialNumber.generate_trial_serials(count)
                self.message_user(
                    request, 
                    f"Successfully generated {len(serials)} trial serial numbers",
                    messages.SUCCESS
                )
                return redirect('admin:serial_management_serialnumber_changelist')
        else:
            form = BulkTrialSerialForm()
        
        context = {
            'title': 'Generate Trial Serials',
            'form': form,
            'opts': self.model._meta,
        }
        return TemplateResponse(request, 'admin/serial_management/serialnumber/generate_trials.html', context)
    
    def generate_5_trials(self, request):
        """Generate 5 trial serials quickly."""
        serials = SerialNumber.generate_trial_serials(5)
        self.message_user(
            request, 
            f"Successfully generated 5 trial serial numbers", 
            messages.SUCCESS
        )
        return redirect('admin:serial_management_serialnumber_changelist')
    
    def generate_20_trials(self, request):
        """Generate 20 trial serials quickly."""
        serials = SerialNumber.generate_trial_serials(20)
        self.message_user(
            request, 
            f"Successfully generated 20 trial serial numbers", 
            messages.SUCCESS
        )
        return redirect('admin:serial_management_serialnumber_changelist')
    
    def generate_50_trials(self, request):
        """Generate 50 trial serials quickly."""
        serials = SerialNumber.generate_trial_serials(50)
        
        # Create a formatted message with the actual serial codes
        serial_codes = "<br>".join([serial.code for serial in serials])
        message = format_html(
            """
            <p>Successfully generated 50 trial serial numbers!</p>
            <div style="margin-top: 10px; max-height: 200px; overflow-y: auto; padding: 10px; background-color: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px;">
                <strong>Serial Numbers:</strong><br>
                {}
            </div>
            """,
            serial_codes
        )
        
        self.message_user(
            request, 
            message,
            messages.SUCCESS
        )
        
        # Check if we're coming from admin index (referrer check)
        referer = request.META.get('HTTP_REFERER', '')
        if 'admin/' in referer and not 'serial_management' in referer:
            return redirect('admin:index')
        
        return redirect('admin:serial_management_serialnumber_changelist')
    
    def generate_trial_serials(self, request, queryset):
        """Generate new trial serial numbers"""
        count = 10  # Default number of serials to generate
        serials = SerialNumber.generate_trial_serials(count)
        self.message_user(request, f"Generated {len(serials)} new trial serial numbers")
    generate_trial_serials.short_description = "Generate 10 new trial serial numbers"
    
    def cancel_trial_serials(self, request, queryset):
        """Cancel unused trial serial numbers"""
        # Filter to only affect trial serials that haven't been assigned to users
        trial_serials = queryset.filter(is_trial=True, user__isnull=True)
        count = trial_serials.count()
        trial_serials.delete()
        self.message_user(request, f"Deleted {count} unused trial serial numbers")
    cancel_trial_serials.short_description = "Delete selected unused trial serial numbers"

@admin.register(RechargeRequest)
class RechargeRequestAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone_number', 'status', 'requested_at', 'processed_at')
    list_filter = ('status', 'requested_at', 'processed_at')
    search_fields = ('user__username', 'phone_number')
    readonly_fields = ('requested_at',)
