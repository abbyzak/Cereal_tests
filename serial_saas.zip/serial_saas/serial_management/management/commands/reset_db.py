import os
from django.core.management.base import BaseCommand
from django.core.management import call_command
from django.contrib.auth import get_user_model
from django.conf import settings
import getpass
import shutil

User = get_user_model()

class Command(BaseCommand):
    help = 'Reset database, flush all data, and create a new admin user'

    def add_arguments(self, parser):
        parser.add_argument(
            '--no-input',
            action='store_true',
            help='Skip confirmation prompts',
        )
        parser.add_argument(
            '--username',
            type=str,
            help='Admin username',
        )
        parser.add_argument(
            '--email',
            type=str,
            help='Admin email',
        )
        parser.add_argument(
            '--password',
            type=str,
            help='Admin password',
        )

    def handle(self, *args, **options):
        no_input = options.get('no_input')
        username = options.get('username')
        email = options.get('email')
        password = options.get('password')
        
        if not no_input:
            self.stdout.write(self.style.WARNING(
                'WARNING: This will DELETE ALL DATA in your database!'
            ))
            confirm = input('Are you sure you want to proceed? [y/N]: ')
            if confirm.lower() != 'y':
                self.stdout.write(self.style.SUCCESS('Operation cancelled.'))
                return
        
        # Backup the current database
        db_path = settings.DATABASES['default']['NAME']
        if os.path.exists(db_path):
            backup_path = f"{db_path}.bak"
            self.stdout.write(f"Backing up database to {backup_path}")
            try:
                shutil.copy2(db_path, backup_path)
                self.stdout.write(self.style.SUCCESS(f"Database backup created at {backup_path}"))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f"Failed to backup database: {e}"))
                if not no_input:
                    confirm = input('Continue without backup? [y/N]: ')
                    if confirm.lower() != 'y':
                        self.stdout.write(self.style.SUCCESS('Operation cancelled.'))
                        return
        
        # Delete the database file
        if os.path.exists(db_path):
            try:
                os.remove(db_path)
                self.stdout.write(self.style.SUCCESS("Database file deleted"))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f"Failed to delete database file: {e}"))
                return
        
        # Run migrate to create a fresh database
        self.stdout.write("Creating new database...")
        call_command('migrate')
        
        # Create admin user
        if not username and not no_input:
            username = input('Enter admin username (default: admin): ') or 'admin'
        elif not username:
            username = 'admin'
            
        if not email and not no_input:
            email = input('Enter admin email (default: admin@example.com): ') or 'admin@example.com'
        elif not email:
            email = 'admin@example.com'
            
        if not password and not no_input:
            password = getpass.getpass('Enter admin password: ')
            if not password:
                self.stdout.write(self.style.ERROR('Password cannot be empty'))
                return
        elif not password:
            password = 'admin'  # Default password for non-interactive mode
        
        # Create the admin user
        try:
            admin_user = User.objects.create_superuser(
                username=username,
                email=email,
                password=password
            )
            self.stdout.write(self.style.SUCCESS(
                f'Successfully created admin user: {username}'
            ))
        except Exception as e:
            self.stdout.write(self.style.ERROR(
                f'Failed to create admin user: {e}'
            ))
            return
        
        self.stdout.write(self.style.SUCCESS(
            'Database has been reset successfully!'
        ))
        self.stdout.write(self.style.SUCCESS(
            f'You can now login with:\nUsername: {username}\nPassword: {"*" * len(password)}'
        )) 