import random
import string
from django.core.management.base import BaseCommand
from serial_management.models import SerialNumber


class Command(BaseCommand):
    help = 'Creates test serial numbers for development and testing'

    def add_arguments(self, parser):
        parser.add_argument(
            '--count',
            type=int,
            default=10,
            help='Number of serial numbers to generate (default: 10)'
        )
        parser.add_argument(
            '--prefix',
            type=str,
            default='TEST',
            help='Prefix for the serial numbers (default: "TEST")'
        )

    def generate_serial_key(self, prefix):
        """Generate a random serial key with a specific prefix."""
        # Create 3 groups of 4 random alphanumeric characters
        groups = []
        for _ in range(3):
            group = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
            groups.append(group)
        
        # Join with hyphens and add the prefix
        return f"{prefix}-{'-'.join(groups)}"

    def handle(self, *args, **options):
        count = options['count']
        prefix = options['prefix']
        
        serials_created = 0
        
        # Keep track of generated keys to avoid duplicates
        generated_keys = set()
        existing_keys = set(SerialNumber.objects.values_list('code', flat=True))
        
        for _ in range(count):
            # Generate a unique serial key
            while True:
                serial_key = self.generate_serial_key(prefix)
                if serial_key not in generated_keys and serial_key not in existing_keys:
                    break
            
            generated_keys.add(serial_key)
            
            # Create the serial number
            SerialNumber.objects.create(code=serial_key)
            serials_created += 1
            
            self.stdout.write(f"Created serial number: {serial_key}")
        
        self.stdout.write(self.style.SUCCESS(f"Successfully created {serials_created} test serial numbers")) 