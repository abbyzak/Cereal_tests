from rest_framework import serializers
from serial_management.models import SerialNumber, RechargeRequest
from accounts.api.serializers import UserSerializer

class SerialNumberSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    time_remaining = serializers.SerializerMethodField()
    is_expired = serializers.SerializerMethodField()
    is_hash_registered = serializers.SerializerMethodField()
    
    class Meta:
        model = SerialNumber
        fields = ['id', 'code', 'user', 'created_at', 'activated_at', 'expires_at', 
                 'is_active', 'time_remaining', 'is_expired', 'exe_hash', 'first_validated_at',
                 'is_hash_registered']
        read_only_fields = ['id', 'created_at', 'activated_at', 'expires_at', 
                           'is_active', 'time_remaining', 'is_expired', 'exe_hash', 'first_validated_at',
                           'is_hash_registered']
    
    def get_time_remaining(self, obj):
        return obj.time_remaining()
    
    def get_is_expired(self, obj):
        return obj.is_expired()
        
    def get_is_hash_registered(self, obj):
        return obj.exe_hash is not None

class RechargeRequestSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    assigned_serial = SerialNumberSerializer(read_only=True)
    
    class Meta:
        model = RechargeRequest
        fields = ['id', 'user', 'phone_number', 'requested_at', 'status', 
                 'processed_at', 'assigned_serial']
        read_only_fields = ['id', 'user', 'requested_at', 'status', 
                           'processed_at', 'assigned_serial']
    
    def create(self, validated_data):
        validated_data['user'] = self.context['request'].user
        return super().create(validated_data)

class RechargeRequestCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = RechargeRequest
        fields = ['phone_number']

class ValidateSerialSerializer(serializers.Serializer):
    serial_code = serializers.CharField(required=True, max_length=50)
    exe_hash = serializers.CharField(required=True, max_length=100) 