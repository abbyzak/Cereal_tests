from django.db import models
from django.utils import timezone
from accounts.models import User
import math
from django.utils.crypto import get_random_string

class SerialNumber(models.Model):
    code = models.CharField(max_length=50, unique=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='serial_numbers', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    activated_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=False)
    is_trial = models.BooleanField(default=False, help_text="Whether this is a trial serial (5 minutes)")
    exe_hash = models.CharField(max_length=100, null=True, blank=True, help_text="Hash of the executable that first validated this serial")
    first_validated_at = models.DateTimeField(null=True, blank=True, help_text="When this serial was first validated")
    
    def __str__(self):
        return f"{self.code} - {self.user.username if self.user else 'Unassigned'}"
    
    def activate(self, user):
        """
        Activate a serial number for a user.
        """
        if self.user is not None and self.user != user:
            raise ValueError(f"Serial number already assigned to {self.user}")
        
        self.user = user
        self.is_active = True
        self.activated_at = timezone.now()
        
        # If it's a trial serial, expire in 5 minutes
        if self.is_trial:
            self.expires_at = self.activated_at + timezone.timedelta(minutes=5)
        # Otherwise, regular 24-hour duration
        else:
            self.expires_at = self.activated_at + timezone.timedelta(hours=24)
        
        self.save()
        return self
    
    def is_expired(self):
        """Check if serial number has expired"""
        if not self.expires_at:
            return True
        return timezone.now() > self.expires_at
    
    def time_remaining(self):
        """Return remaining time in hours"""
        if not self.expires_at or self.is_expired():
            return 0
        remaining = self.expires_at - timezone.now()
        return max(0, remaining.total_seconds() / 3600)
        
    def time_remaining_seconds(self):
        """Return remaining time in seconds for precise countdown"""
        if not self.expires_at or self.is_expired():
            return 0
        remaining = self.expires_at - timezone.now()
        return max(0, remaining.total_seconds())
    
    def time_remaining_display(self):
        """Return formatted time remaining for display (HH:MM:SS)"""
        seconds = self.time_remaining_seconds()
        if seconds <= 0:
            return "00:00:00"
            
        hours = math.floor(seconds / 3600)
        minutes = math.floor((seconds % 3600) / 60)
        seconds = math.floor(seconds % 60)
        
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    
    def time_remaining_percent(self):
        """Return percentage of time remaining (for progress bars)"""
        if not self.activated_at or not self.expires_at:
            return 0
            
        total_duration = (self.expires_at - self.activated_at).total_seconds()
        if total_duration <= 0:
            return 0
            
        remaining = self.time_remaining_seconds()
        percentage = (remaining / total_duration) * 100
        return min(100, max(0, percentage))
    
    @classmethod
    def generate_serial_numbers(cls, count=1):
        """
        Generate random serial numbers and save them to the database.
        """
        serials = []
        for _ in range(count):
            serial = cls.objects.create(
                code=cls.generate_code(),
            )
            serials.append(serial)
        return serials

    @classmethod
    def generate_trial_serials(cls, count=10):
        """
        Generate trial serial numbers and save them to the database.
        These serials will expire 5 minutes after activation.
        """
        serials = []
        for _ in range(count):
            # Generate a code with a TRIAL prefix for easy identification
            code = "TRIAL-" + cls.generate_code()[3:]  # Replace the SN- with TRIAL-
            
            # Create the trial serial
            serial = cls.objects.create(
                code=code,
                is_trial=True,
            )
            serials.append(serial)
        return serials

    @classmethod
    def generate_code(cls):
        """
        Generate a unique serial code.
        """
        # Loop until we generate a unique code
        while True:
            # For trial serials, add a "T-" prefix for easy identification
            code = f"SN-{get_random_string(length=12, allowed_chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')}"
            if not cls.objects.filter(code=code).exists():
                return code

class RechargeRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='recharge_requests')
    phone_number = models.CharField(max_length=15)
    requested_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    processed_at = models.DateTimeField(null=True, blank=True)
    processed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, 
                                    related_name='processed_recharges')
    assigned_serial = models.ForeignKey(SerialNumber, on_delete=models.SET_NULL, null=True, blank=True)
    
    def __str__(self):
        return f"{self.user.username} - {self.status} - {self.requested_at.strftime('%Y-%m-%d %H:%M')}"
    
    def approve(self, admin_user, serial_number):
        """Approve recharge request and assign serial number"""
        self.status = 'approved'
        self.processed_at = timezone.now()
        self.processed_by = admin_user
        self.assigned_serial = serial_number
        self.save()
        
        # Activate the serial number for the user
        serial_number.activate(self.user)
        
    def reject(self, admin_user):
        """Reject recharge request"""
        self.status = 'rejected'
        self.processed_at = timezone.now()
        self.processed_by = admin_user
        self.save()
