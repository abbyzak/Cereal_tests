#!/bin/bash

# Set production environment variables
export DJANGO_SETTINGS_MODULE=serial_saas_project.settings
export DJANGO_SECRET_KEY="your-secure-secret-key-here"
export DJANGO_DEBUG=False
export DJANGO_ALLOWED_HOSTS="*"

# Collect static files
echo "Collecting static files..."
python manage.py collectstatic --noinput

# Apply migrations
echo "Applying database migrations..."
python manage.py migrate

# Start Gunicorn with 8 Uvicorn workers
echo "Starting server with 8 Uvicorn workers..."
gunicorn serial_saas_project.wsgi:application \
    --workers=8 \
    --worker-class=uvicorn.workers.UvicornWorker \
    --bind=0.0.0.0:8000 \
    --log-level=info \
    --access-logfile=- \
    --error-logfile=- 