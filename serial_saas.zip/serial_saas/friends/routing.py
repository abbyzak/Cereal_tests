from django.urls import path

# No WebSocket URLs since we're not using WebSockets anymore
websocket_urlpatterns = [] 