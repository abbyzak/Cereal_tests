from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
# Only keep chatroom-related API endpoints

app_name = 'friends'

urlpatterns = [
    # Include the router URLs
    path('', include(router.urls)),
    
    # Remove old chat API endpoints
    
    # Chatroom web views
    path('chat/', views.chat_list, name='chat_list'),
    path('chat/create/', views.create_chatroom_view, name='create_chatroom_view'),
    path('chat/join/', views.join_chatroom_view, name='join_chatroom_view'),
    path('chat/room/<uuid:room_id>/', views.chatroom_detail, name='chatroom_detail'),
    
    # Chatroom API endpoints
    path('api/chatroom/create/', views.api_create_chatroom, name='api_create_chatroom'),
    path('api/chatroom/<uuid:room_id>/', views.api_get_chatroom, name='api_get_chatroom'),
    path('api/chatroom/<uuid:room_id>/join/', views.api_join_chatroom, name='api_join_chatroom'),
    path('api/chatroom/<uuid:room_id>/messages/', views.api_get_room_messages, name='api_get_room_messages'),
    path('api/chatroom/<uuid:room_id>/send/', views.api_send_room_message, name='api_send_room_message'),
    path('api/chatroom/<uuid:room_id>/join/', views.join_chatroom_api, name='join_chatroom_api'),
] 