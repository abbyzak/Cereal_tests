import os
import sys
import importlib.util
import site
from pathlib import Path

# Get the site-packages directory
site_packages = site.getsitepackages()[0]

# Path to the PostgreSQL base.py file
postgresql_base_path = os.path.join(site_packages, 'django', 'db', 'backends', 'postgresql', 'base.py')

# Create a backup if it doesn't exist
backup_path = postgresql_base_path + '.bak'
if not os.path.exists(backup_path):
    print(f"Creating backup of {postgresql_base_path}")
    with open(postgresql_base_path, 'r') as src:
        with open(backup_path, 'w') as dst:
            dst.write(src.read())

# Modify the file to use SQLite for connections
print(f"Modifying {postgresql_base_path}")
with open(postgresql_base_path, 'r') as f:
    content = f.read()

# Add a monkeypatch to redirect PostgreSQL to SQLite
modified_content = content.replace(
    "class DatabaseWrapper(BaseDatabaseWrapper):",
    """class DatabaseWrapper(BaseDatabaseWrapper):
    def get_new_connection(self, conn_params):
        # Use SQLite connection instead
        from django.db.backends.sqlite3.base import DatabaseWrapper as SQLite3DatabaseWrapper
        from pathlib import Path
        sqlite_conn_params = {'database': Path(__file__).resolve().parent.parent.parent.parent.parent.parent / 'db.sqlite3'}
        sqlite_wrapper = SQLite3DatabaseWrapper({'NAME': sqlite_conn_params['database']})
        return sqlite_wrapper.get_new_connection(sqlite_conn_params)
        
    def _original_get_new_connection(self, conn_params):
        # Original method preserved for reference"""
)

with open(postgresql_base_path, 'w') as f:
    f.write(modified_content)

print("PostgreSQL backend modified to use SQLite. Now you can run migrations and use the app.")
print("To restore original file, delete the modified file and rename the .bak file.") 