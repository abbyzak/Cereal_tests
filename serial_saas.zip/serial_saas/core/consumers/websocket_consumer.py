from channels.generic.websocket import AsyncWebsocketConsumer
import json
import logging

logger = logging.getLogger(__name__)

class TestConsumer(AsyncWebsocketConsumer):
    """
    A basic WebSocket consumer for testing purposes.
    """
    
    async def connect(self):
        """
        Called when the WebSocket is handshaking as part of the connection process.
        """
        # Accept the connection
        logger.info("WebSocket connection established")
        await self.accept()
        
        # Send a welcome message
        await self.send(text_data=json.dumps({
            'type': 'connection_established',
            'message': 'You are now connected to the WebSocket server!'
        }))
    
    async def disconnect(self, close_code):
        """
        Called when the WebSocket closes for any reason.
        """
        logger.info(f"WebSocket connection closed with code: {close_code}")
    
    async def receive(self, text_data):
        """
        Called when we get a text frame from the client.
        """
        logger.info(f"Received message: {text_data}")
        
        # Parse the received JSON
        try:
            text_data_json = json.loads(text_data)
            message = text_data_json.get('message', '')
            
            # Echo the message back to the client
            await self.send(text_data=json.dumps({
                'type': 'echo',
                'message': message,
                'received_at': 'server'
            }))
        
        except json.JSONDecodeError:
            logger.error("Received invalid JSON data")
            await self.send(text_data=json.dumps({
                'type': 'error',
                'message': 'Invalid JSON format'
            }))
        except Exception as e:
            logger.error(f"Error processing message: {str(e)}")
            await self.send(text_data=json.dumps({
                'type': 'error',
                'message': f'Error processing message: {str(e)}'
            })) 