from django.contrib import admin
from .models import FAQ, ApplicationBinary, PaymentMethod

@admin.register(FAQ)
class FAQAdmin(admin.ModelAdmin):
    list_display = ('question', 'category', 'order')
    list_filter = ('category',)
    search_fields = ('question', 'answer')
    ordering = ('category', 'order')

@admin.register(ApplicationBinary)
class ApplicationBinaryAdmin(admin.ModelAdmin):
    list_display = ('platform', 'version', 'is_latest', 'release_date')
    list_filter = ('platform', 'is_latest')
    search_fields = ('version', 'release_notes')
    readonly_fields = ('release_date',)

@admin.register(PaymentMethod)
class PaymentMethodAdmin(admin.ModelAdmin):
    list_display = ('name', 'account_number', 'is_active', 'is_default')
    list_filter = ('is_active', 'is_default')
    search_fields = ('name', 'account_number', 'account_name', 'instructions')
    ordering = ('-is_default', 'name')
    actions = ['make_active', 'make_inactive', 'set_as_default']
    
    def make_active(self, request, queryset):
        queryset.update(is_active=True)
    make_active.short_description = "Mark selected payment methods as active"
    
    def make_inactive(self, request, queryset):
        queryset.update(is_active=False)
    make_inactive.short_description = "Mark selected payment methods as inactive"
    
    def set_as_default(self, request, queryset):
        if queryset.count() != 1:
            self.message_user(request, "Please select only one payment method to set as default")
            return
        payment_method = queryset.first()
        # First update all methods to not be default
        PaymentMethod.objects.all().update(is_default=False)
        # Then set this one as default
        payment_method.is_default = True
        payment_method.save()
        self.message_user(request, f"{payment_method.name} has been set as the default payment method")
    set_as_default.short_description = "Set selected payment method as default"
