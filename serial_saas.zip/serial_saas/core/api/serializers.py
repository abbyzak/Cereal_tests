from rest_framework import serializers
from core.models import FAQ, ApplicationBinary

class FAQSerializer(serializers.ModelSerializer):
    class Meta:
        model = FAQ
        fields = ['id', 'question', 'answer', 'category', 'order']
        read_only_fields = ['id']

class ApplicationBinarySerializer(serializers.ModelSerializer):
    download_url = serializers.SerializerMethodField()
    
    class Meta:
        model = ApplicationBinary
        fields = ['id', 'platform', 'version', 'release_notes', 'release_date', 
                 'is_latest', 'download_url']
        read_only_fields = ['id', 'release_date', 'download_url']
    
    def get_download_url(self, obj):
        request = self.context.get('request')
        if obj.binary_file and hasattr(obj.binary_file, 'url') and request:
            return request.build_absolute_uri(obj.binary_file.url)
        return None 