from rest_framework import generics, permissions
from rest_framework.response import Response
from django.db.models import Q

from core.models import FAQ, ApplicationBinary
from .serializers import FAQSerializer, ApplicationBinarySerializer

class FAQListAPIView(generics.ListAPIView):
    """
    Get a list of all FAQs, optionally filtered by category
    """
    serializer_class = FAQSerializer
    permission_classes = [permissions.AllowAny]
    
    def get_queryset(self):
        queryset = FAQ.objects.all().order_by('category', 'order')
        category = self.request.query_params.get('category', None)
        
        if category:
            queryset = queryset.filter(category=category)
            
        return queryset

class ApplicationBinaryListAPIView(generics.ListAPIView):
    """
    Get a list of all application binaries, optionally filtered by platform
    """
    serializer_class = ApplicationBinarySerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        queryset = ApplicationBinary.objects.all().order_by('-release_date')
        platform = self.request.query_params.get('platform', None)
        latest_only = self.request.query_params.get('latest', 'false').lower() == 'true'
        
        if platform:
            queryset = queryset.filter(platform=platform)
        
        if latest_only:
            # Get the latest version for each platform
            platforms = ApplicationBinary.objects.values_list('platform', flat=True).distinct()
            filter_condition = Q()
            
            for platform in platforms:
                latest = ApplicationBinary.objects.filter(platform=platform).order_by('-release_date').first()
                if latest:
                    filter_condition |= Q(id=latest.id)
            
            queryset = queryset.filter(filter_condition)
            
        return queryset 