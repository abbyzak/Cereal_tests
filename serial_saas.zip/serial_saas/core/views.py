from django.shortcuts import render
from django.contrib.auth.decorators import login_required

from .models import FAQ, ApplicationBinary

def home(request):
    """Home page with product overview and CTA buttons"""
    return render(request, 'core/home.html')

def pricing(request):
    """Pricing page showing the cost of service"""
    return render(request, 'core/pricing.html')

@login_required
def downloads(request):
    """Downloads page with binaries sorted by platform"""
    windows_binaries = ApplicationBinary.objects.filter(platform='windows').order_by('-version')
    macos_binaries = ApplicationBinary.objects.filter(platform='macos').order_by('-version')
    linux_binaries = ApplicationBinary.objects.filter(platform='linux').order_by('-version')
    
    context = {
        'windows_binaries': windows_binaries,
        'macos_binaries': macos_binaries,
        'linux_binaries': linux_binaries,
        'latest_windows': windows_binaries.filter(is_latest=True).first(),
        'latest_macos': macos_binaries.filter(is_latest=True).first(),
        'latest_linux': linux_binaries.filter(is_latest=True).first(),
    }
    
    return render(request, 'core/downloads.html', context)

def faq(request):
    """FAQ page with categorized questions and answers"""
    faqs_by_category = {}
    categories = FAQ.CATEGORY_CHOICES
    
    for category_code, category_name in categories:
        faqs_by_category[category_name] = FAQ.objects.filter(category=category_code)
    
    context = {
        'faqs_by_category': faqs_by_category,
        'categories': [name for _, name in categories],
    }
    
    return render(request, 'core/faq.html', context)

def demo(request):
    """Demo page with embedded video content"""
    return render(request, 'core/demo.html')

def websocket_test(request):
    """
    Render the WebSocket test page.
    """
    return render(request, 'core/websocket_test.html')
