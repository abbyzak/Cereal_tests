#!/bin/bash

# Simple Serial Number Validation Script using curl
# Makes a POST request to validate a serial number with a random string as the exe hash.

# Constants
API_BASE_URL="http://localhost:8000"  # Change to your actual API URL
VALIDATE_ENDPOINT="/api/v1/serial/validate/"

# Generate a random string to use as exe hash
generate_random_hash() {
    # Generate a 32-character random string for the exe hash
    cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1
}

# Print script header
echo "Serial Number Validation with curl"
echo "=================================="

# Get the serial number from the user
echo -n "Enter your serial number: "
read SERIAL_CODE

# Generate a random hash
EXE_HASH=$(generate_random_hash)
echo "Using random exe hash: $EXE_HASH"

# Create JSON payload
PAYLOAD="{\"serial_code\":\"$SERIAL_CODE\",\"exe_hash\":\"$EXE_HASH\"}"
echo -e "\nPayload: $PAYLOAD"

# Make the API request using curl
echo -e "\nSending request to: $API_BASE_URL$VALIDATE_ENDPOINT"
echo -e "Response:\n"

curl -X POST "$API_BASE_URL$VALIDATE_ENDPOINT" \
    -H "Content-Type: application/json" \
    -d "$PAYLOAD" \
    -v | json_pp

echo -e "\nRequest completed." 