#!/usr/bin/env python3
"""
Example Serial SaaS API Client
This demonstrates how to validate a serial number with an exe hash.
"""

import requests
import hashlib
import platform
import json
import sys
import uuid

# Constants
API_BASE_URL = "http://localhost:8000"  # Change to your actual API URL
VALIDATE_ENDPOINT = "/api/v1/serial/validate/"

def generate_exe_hash():
    """
    Generate a unique hash for this machine/executable combination.
    In a real application, you would want to store this hash somewhere
    to reuse it for subsequent validations.
    """
    # Get machine-specific information
    machine_info = {
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "node": platform.node(),
        # Generate a unique installation ID
        "installation_id": str(uuid.uuid4())
    }
    
    # In a real app, you would use the actual executable file hash
    try:
        # Try to get the hash of the current executable
        exe_path = sys.argv[0]
        with open(exe_path, 'rb') as f:
            file_content = f.read()
            file_hash = hashlib.sha256(file_content).hexdigest()
        machine_info["file_hash"] = file_hash
    except:
        # Fallback to a random ID if we can't read the file
        machine_info["file_hash"] = str(uuid.uuid4())
    
    # Create a deterministic hash from the machine info
    serialized = json.dumps(machine_info, sort_keys=True).encode('utf-8')
    hash_object = hashlib.sha256(serialized)
    
    return hash_object.hexdigest()

def validate_serial(serial_code, exe_hash):
    """
    Validate a serial number with the API
    """
    url = f"{API_BASE_URL}{VALIDATE_ENDPOINT}"
    
    payload = {
        "serial_code": serial_code,
        "exe_hash": exe_hash
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers)
        
        # Print status code for debugging
        print(f"Status Code: {response.status_code}")
        
        # Parse the response
        if response.status_code == 200:
            data = response.json()
            print("\nSerial Validation Successful!")
            print("===========================")
            print(f"Serial: {data.get('code')}")
            print(f"Time Remaining: {data.get('time_remaining', 0):.2f} hours")
            print(f"Expires At: {data.get('expires_at')}")
            print(f"Is Hash Registered: {data.get('is_hash_registered', False)}")
            
            if data.get('first_validated_at') and data.get('is_hash_registered'):
                print(f"First Validated At: {data.get('first_validated_at')}")
                print(f"Exe Hash: {data.get('exe_hash')}")
            
            return True
        else:
            error_data = response.json()
            print("\nValidation Failed:")
            print(f"Error: {error_data.get('error', 'Unknown error')}")
            return False
    
    except requests.exceptions.RequestException as e:
        print(f"\nAPI Connection Error: {e}")
        return False
    except Exception as e:
        print(f"\nUnexpected Error: {e}")
        return False

def main():
    print("Serial SaaS API Example Client")
    print("=============================")
    
    # Generate a machine-specific hash
    exe_hash = generate_exe_hash()
    print(f"Generated Exe Hash: {exe_hash}")
    
    # Get the serial number from the user
    serial_code = input("\nEnter your serial number: ")
    
    # Validate the serial number
    validate_serial(serial_code, exe_hash)

if __name__ == "__main__":
    main() 