"""
Create superuser automatically in Django
"""
import os
import django
from django.db import IntegrityError

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'serial_saas_project.settings')
django.setup()

from accounts.models import User  # Use the custom user model

USERNAME = os.environ.get('DJANGO_SUPERUSER_USERNAME', 'admin')
EMAIL = os.environ.get('DJANGO_SUPERUSER_EMAIL', 'admin@example.com')
PASSWORD = os.environ.get('DJANGO_SUPERUSER_PASSWORD', 'admin')

try:
    superuser = User.objects.create_superuser(
        username=USERNAME,
        email=EMAIL,
        password=PASSWORD
    )
    superuser.is_active = True
    superuser.is_admin = True
    superuser.is_staff = True
    superuser.save()
    print(f"Superuser '{USERNAME}' created successfully!")
except IntegrityError:
    print(f"Superuser '{USERNAME}' already exists.")
except Exception as e:
    print(f"Error creating superuser: {e}") 