from django.urls import path
from .consumers.websocket_consumer import TestConsumer

websocket_urlpatterns = [
    path('ws/test/', TestConsumer.as_asgi()),
]