from django.db import models

# Create your models here.

class FAQ(models.Model):
    CATEGORY_CHOICES = [
        ('general', 'General'),
        ('account', 'Account'),
        ('payment', 'Payment'),
        ('technical', 'Technical'),
    ]
    
    question = models.CharField(max_length=255)
    answer = models.TextField()
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='general')
    order = models.PositiveSmallIntegerField(default=0)
    
    def __str__(self):
        return self.question
    
    class Meta:
        ordering = ['category', 'order']

class PaymentMethod(models.Model):
    """
    Model for storing payment method instructions that can be configured by the admin.
    These instructions will be shown to users when they request a recharge.
    """
    name = models.CharField(max_length=100, help_text="Payment method name (e.g. EasyPaisa, JazzCash)")
    instructions = models.TextField(help_text="Payment instructions to be displayed to users")
    account_number = models.CharField(max_length=50, help_text="Account or phone number for payment")
    account_name = models.CharField(max_length=100, help_text="Name of account holder")
    
    is_active = models.BooleanField(default=True, help_text="Whether this payment method is currently active")
    is_default = models.BooleanField(default=False, help_text="Whether this is the default payment method")
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):
        # If this payment method is set as default, unset default for all other payment methods
        if self.is_default:
            PaymentMethod.objects.filter(is_default=True).update(is_default=False)
        super().save(*args, **kwargs)
    
    class Meta:
        ordering = ['-is_default', 'name']

class ApplicationBinary(models.Model):
    PLATFORM_CHOICES = [
        ('windows', 'Windows'),
        ('macos', 'macOS'),
        ('linux', 'Linux'),
    ]
    
    platform = models.CharField(max_length=10, choices=PLATFORM_CHOICES)
    version = models.CharField(max_length=20)
    binary_file = models.FileField(upload_to='binaries/')
    release_notes = models.TextField()
    release_date = models.DateField(auto_now_add=True)
    is_latest = models.BooleanField(default=True)
    
    class Meta:
        verbose_name_plural = 'Application Binaries'
        ordering = ['-release_date']
        
    def __str__(self):
        return f"{self.platform} v{self.version}"
    
    def save(self, *args, **kwargs):
        # When saving a new latest version, set all other versions of same platform to not latest
        if self.is_latest:
            ApplicationBinary.objects.filter(
                platform=self.platform, 
                is_latest=True
            ).update(is_latest=False)
        super().save(*args, **kwargs)
