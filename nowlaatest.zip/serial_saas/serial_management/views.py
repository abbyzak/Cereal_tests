from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib import messages
from django.utils import timezone
from django.http import JsonResponse
from django.db import transaction

from .models import SerialNumber, RechargeRequest
from .forms import SerialNumberForm, BulkSerialNumberForm, RechargeApprovalForm, RechargeForm
from accounts.forms import RechargeRequestForm
from accounts.models import User
from core.models import PaymentMethod

@login_required
def activate_trial(request):
    """
    Activate a trial serial number for a user.
    Each user can only use one trial serial in their account lifetime.
    """
    # Check if user already has an active serial number
    active_serial = SerialNumber.objects.filter(
        user=request.user,
        is_active=True,
        expires_at__gt=timezone.now()
    ).first()
    
    if active_serial:
        messages.warning(request, "You already have an active serial number. Please wait until it expires.")
        return redirect('accounts:dashboard')
    
    # Check if user has a pending recharge request
    pending_recharge = RechargeRequest.objects.filter(
        user=request.user,
        status='pending'
    ).exists()
    
    if pending_recharge:
        messages.warning(request, "You have a pending recharge request. Please wait for it to be processed.")
        return redirect('recharge_status')
    
    # Check if user has already used a trial serial before
    has_used_trial = SerialNumber.objects.filter(
        user=request.user,
        is_trial=True
    ).exists()
    
    if has_used_trial:
        messages.warning(request, "You have already used your trial serial. Each user is limited to one trial.")
        return redirect('recharge')
    
    # Find an available trial serial
    trial_serial = SerialNumber.objects.filter(
        is_trial=True,
        user__isnull=True,
        is_active=False
    ).first()
    
    if not trial_serial:
        messages.error(request, "No trial serials are currently available. Please contact the administrator or purchase a regular serial.")
        return redirect('accounts:dashboard')
    
    # Activate the trial serial for the user
    trial_serial.activate(request.user)
    
    messages.success(
        request, 
        f"Your trial serial has been activated! You now have 5 minutes to explore the full features. Serial: {trial_serial.code}"
    )
    
    return redirect('accounts:dashboard')

@login_required
def recharge(request):
    # Check if user already has an active serial number
    active_serial = SerialNumber.objects.filter(
        user=request.user,
        is_active=True,
        expires_at__gt=timezone.now()
    ).first()
    
    # Check if user has a pending recharge request
    pending_recharge = RechargeRequest.objects.filter(
        user=request.user,
        status='pending'
    ).first()  # Changed to first() to get the actual object
    
    # Get payment methods from the database
    payment_methods = PaymentMethod.objects.filter(is_active=True).order_by('-is_default', 'name')
    default_payment_method = payment_methods.filter(is_default=True).first() or payment_methods.first()
    
    # Check if the user has already used their trial
    has_used_trial = SerialNumber.objects.filter(
        user=request.user,
        is_trial=True
    ).exists()
    
    if request.method == 'POST':
        form = RechargeForm(request.POST)
        if form.is_valid():
            # Create a new recharge request
            recharge_request = RechargeRequest(
                user=request.user,
                phone_number=form.cleaned_data['phone_number'],
                status='pending'
            )
            recharge_request.save()
            
            # Check if this is an AJAX request (via fetch)
            is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest' or 'application/json' in request.headers.get('Accept', '')
            
            if is_ajax:
                # For AJAX requests, just return the current page
                # The JavaScript will handle displaying payment methods
                return render(request, 'serial_management/recharge.html', {
                    'form': form,
                    'active_serial': active_serial,
                    'pending_recharge': recharge_request,  # Use the newly created request
                    'payment_methods': payment_methods,
                    'default_payment_method': default_payment_method,
                    'has_used_trial': has_used_trial,
                    'show_payment': True
                })
            else:
                # For regular form submissions, redirect to recharge_status
                messages.success(
                    request, 
                    f"Your recharge request has been received. Please follow the payment instructions to complete your purchase."
                )
                return redirect('recharge_status')
    else:
        # Pre-fill phone number if the user has one
        initial_data = {}
        if request.user.phone_number:
            initial_data['phone_number'] = request.user.phone_number
        form = RechargeForm(initial=initial_data)
    
    # Check if we should show payment methods (e.g., after form submission)
    show_payment = request.GET.get('payment') == 'show' or pending_recharge is not None
    
    context = {
        'form': form,
        'active_serial': active_serial,
        'pending_recharge': pending_recharge,
        'payment_methods': payment_methods,
        'default_payment_method': default_payment_method,
        'has_used_trial': has_used_trial,
        'show_payment': show_payment
    }
    
    return render(request, 'serial_management/recharge.html', context)

@login_required
def recharge_status(request):
    # Get all recharge requests for the user
    recharge_requests = RechargeRequest.objects.filter(user=request.user).order_by('-requested_at')
    
    # Get pending recharge request if any
    pending_request = recharge_requests.filter(status='pending').first()
    
    # Get payment methods for displaying instructions
    payment_methods = PaymentMethod.objects.filter(is_active=True).order_by('-is_default', 'name')
    default_payment_method = payment_methods.filter(is_default=True).first() or payment_methods.first()
    
    context = {
        'recharge_requests': recharge_requests,
        'pending_request': pending_request,
        'payment_methods': payment_methods,
        'default_payment_method': default_payment_method,
    }
    
    return render(request, 'serial_management/recharge_status.html', context)

@staff_member_required
def admin_dashboard(request):
    # Get counts for dashboard
    serial_count = SerialNumber.objects.count()
    available_serial_count = SerialNumber.objects.filter(user__isnull=True, is_active=False).count()
    pending_recharge_count = RechargeRequest.objects.filter(status='pending').count()
    active_serial_count = SerialNumber.objects.filter(is_active=True, expires_at__gt=timezone.now()).count()
    
    context = {
        'serial_count': serial_count,
        'available_serial_count': available_serial_count,
        'pending_recharge_count': pending_recharge_count,
        'active_serial_count': active_serial_count,
    }
    
    return render(request, 'serial_management/admin_dashboard.html', context)

@staff_member_required
def serial_number_management(request):
    if request.method == 'POST':
        form = SerialNumberForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Serial number created successfully!")
            return redirect('serial_number_management')
    else:
        form = SerialNumberForm()
    
    bulk_form = BulkSerialNumberForm()
    
    # Get all serial numbers with pagination
    serials = SerialNumber.objects.all().order_by('-created_at')
    
    context = {
        'form': form,
        'bulk_form': bulk_form,
        'serials': serials,
    }
    
    return render(request, 'serial_management/serial_management.html', context)

@staff_member_required
def bulk_serial_creation(request):
    if request.method == 'POST':
        form = BulkSerialNumberForm(request.POST)
        if form.is_valid():
            serials = form.cleaned_data['serial_numbers']
            
            # Create serial numbers
            SerialNumber.objects.bulk_create([
                SerialNumber(code=code) for code in serials
            ])
            
            messages.success(request, f"Successfully created {len(serials)} serial numbers.")
            return redirect('serial_number_management')
    else:
        form = BulkSerialNumberForm()
    
    return render(request, 'serial_management/bulk_serial_creation.html', {'form': form})

@staff_member_required
def pending_recharges(request):
    # Get all pending recharge requests
    pending_requests = RechargeRequest.objects.filter(status='pending').order_by('requested_at')
    
    context = {
        'pending_requests': pending_requests,
    }
    
    return render(request, 'serial_management/pending_recharges.html', context)

@staff_member_required
def approve_recharge(request, request_id):
    recharge_request = get_object_or_404(RechargeRequest, id=request_id, status='pending')
    
    if request.method == 'POST':
        form = RechargeApprovalForm(request.POST)
        if form.is_valid():
            serial_number = form.cleaned_data['serial_number']
            
            # Approve the request and assign serial
            recharge_request.approve(request.user, serial_number)
            
            messages.success(request, f"Recharge request approved and serial number {serial_number.code} assigned.")
            return redirect('pending_recharges')
    else:
        form = RechargeApprovalForm()
    
    context = {
        'form': form,
        'recharge_request': recharge_request,
    }
    
    return render(request, 'serial_management/approve_recharge.html', context)

@staff_member_required
def reject_recharge(request, request_id):
    recharge_request = get_object_or_404(RechargeRequest, id=request_id, status='pending')
    
    # Reject the request
    recharge_request.reject(request.user)
    
    messages.success(request, f"Recharge request from {recharge_request.user.username} has been rejected.")
    return redirect('pending_recharges')
