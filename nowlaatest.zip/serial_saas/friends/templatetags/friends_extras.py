from django import template

register = template.Library()

@register.filter
def get_item(dictionary, key):
    """
    Get an item from a dictionary using the key.
    Used in templates where direct dictionary access is not possible.
    """
    return dictionary.get(str(key), 0) 