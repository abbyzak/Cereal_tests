from django.contrib import admin
from .models import FriendCode, ChatMessage

@admin.register(FriendCode)
class FriendCodeAdmin(admin.ModelAdmin):
    list_display = ('code', 'creator', 'hours_offered', 'created_at', 'expires_at', 'is_used', 'used_by', 'used_at')
    list_filter = ('is_used', 'created_at', 'expires_at')
    search_fields = ('code', 'creator__username', 'creator__email', 'used_by__username', 'used_by__email')
    date_hierarchy = 'created_at'
    readonly_fields = ('code',)

@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ('sender', 'recipient', 'short_message', 'timestamp', 'is_read')
    list_filter = ('is_read', 'timestamp')
    search_fields = ('sender__username', 'sender__email', 'recipient__username', 'recipient__email', 'message')
    date_hierarchy = 'timestamp'
    
    def short_message(self, obj):
        """Returns a truncated message for the list display"""
        max_length = 50
        return (obj.message[:max_length] + '...') if len(obj.message) > max_length else obj.message
    
    short_message.short_description = 'Message'
