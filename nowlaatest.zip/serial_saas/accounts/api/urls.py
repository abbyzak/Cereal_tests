from django.urls import path
from rest_framework.authtoken import views as token_views

from . import views

urlpatterns = [
    path('register/', views.UserRegistrationAPIView.as_view(), name='api_user_register'),
    path('profile/', views.UserProfileAPIView.as_view(), name='api_user_profile'),
] 