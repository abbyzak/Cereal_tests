#!/bin/bash

# Check if virtual environment exists
if [ -d "venv" ]; then
  echo "Activating virtual environment..."
  source venv/bin/activate
fi

# Start Django in background
echo "Starting Django server on port 8000..."
python manage.py runserver 0.0.0.0:8000 &
DJANGO_PID=$!

# Wait for Django to start up
sleep 5

# Start Cloudflare tunnel
echo "Starting Cloudflare tunnel..."
docker run cloudflare/cloudflared:latest tunnel --no-autoupdate run --token eyJhIjoiZjAyNzM4NWFhOTVmYzEyNGE4OTMxMjBjOGU3NDI2N2IiLCJ0IjoiNDhjN2IzOTMtYjdlNS00MjEyLTgyMDYtM2RhNzQxZmFlODY5IiwicyI6Ik1ETTFaV1V5WlRjdFl6TXhZUzAwWmpObUxXSTBZVGt0WWprNU9EbGhOek5sWlRReCJ9

# Clean up Django process when the script is terminated
trap "kill $DJANGO_PID" EXIT
wait 