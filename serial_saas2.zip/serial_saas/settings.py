# Add django-cors-headers to INSTALLED_APPS
INSTALLED_APPS += [
    'corsheaders',
]

ALLOWED_HOSTS = ['buddyboard.io', 'https://buddyboard.io/', 'localhost', '127.0.0.1']
# Add CorsMiddleware near the top of MIDDLEWARE
MIDDLEWARE.insert(0, 'corsheaders.middleware.CorsMiddleware')

# CORS settings - allow all origins
CORS_ALLOW_ALL_ORIGINS = True
CORS_ALLOW_CREDENTIALS = True
CORS_ALLOW_METHODS = [
    'DELETE',
    'GET',
    'OPTIONS',
    'PATCH',
    'POST',
    'PUT',
]
CORS_ALLOW_HEADERS = [
    'accept',
    'accept-encoding',
    'authorization',
    'content-type',
    'dnt',
    'origin',
    'user-agent',
    'x-csrftoken',
    'x-requested-with',
]

# Remove restrictive security headers for development
SECURE_CONTENT_TYPE_NOSNIFF = False
SECURE_BROWSER_XSS_FILTER = False
X_FRAME_OPTIONS = None

# ... rest of your settings ... 
