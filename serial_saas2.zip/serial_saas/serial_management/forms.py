from django import forms
from .models import SerialNumber, RechargeRequest

class SerialNumberForm(forms.ModelForm):
    class Meta:
        model = SerialNumber
        fields = ['code']
    
    def clean_code(self):
        code = self.cleaned_data.get('code')
        if SerialNumber.objects.filter(code=code).exists():
            raise forms.ValidationError("This serial number already exists. Please use a unique code.")
        return code

class BulkSerialNumberForm(forms.Form):
    serial_numbers = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 10}),
        help_text="Enter one serial number per line."
    )
    
    def clean_serial_numbers(self):
        data = self.cleaned_data['serial_numbers']
        lines = data.strip().split('\n')
        serial_numbers = []
        
        existing_serials = set(SerialNumber.objects.values_list('code', flat=True))
        
        for line in lines:
            code = line.strip()
            if not code:
                continue
            
            if code in existing_serials:
                raise forms.ValidationError(f"Serial number '{code}' already exists. Please remove it from the list.")
            
            if code in serial_numbers:
                raise forms.ValidationError(f"Duplicate serial number '{code}' found. Each serial number must be unique.")
            
            serial_numbers.append(code)
        
        if not serial_numbers:
            raise forms.ValidationError("Please enter at least one valid serial number.")
        
        return serial_numbers

class RechargeApprovalForm(forms.Form):
    serial_number = forms.ModelChoiceField(
        queryset=SerialNumber.objects.filter(user__isnull=True, is_active=False),
        required=True,
        empty_label="Select a serial number"
    )
    
    def clean(self):
        cleaned_data = super().clean()
        serial_number = cleaned_data.get('serial_number')
        
        if not serial_number:
            raise forms.ValidationError("You must select a serial number to approve the request.")
        
        return cleaned_data

class RechargeForm(forms.ModelForm):
    class Meta:
        model = RechargeRequest
        fields = ['phone_number']
        widgets = {
            'phone_number': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter your mobile number'
            })
        }

    def clean_phone_number(self):
        phone_number = self.cleaned_data.get('phone_number')
        # Validate phone number format - basic validation
        if not phone_number:
            raise forms.ValidationError("Phone number is required.")
        
        # You could add more validation here, like checking for specific formats
        if not phone_number.isdigit():
            raise forms.ValidationError("Phone number should contain only digits.")
        
        if len(phone_number) < 10 or len(phone_number) > 15:
            raise forms.ValidationError("Phone number should be between 10 and 15 digits.")
        
        return phone_number 