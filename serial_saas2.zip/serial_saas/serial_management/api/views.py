from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.utils import timezone

from serial_management.models import SerialNumber, RechargeRequest
from .serializers import (
    SerialNumberSerializer, 
    RechargeRequestSerializer,
    RechargeRequestCreateSerializer,
    ValidateSerialSerializer
)

class SerialNumberAPIView(generics.RetrieveAPIView):
    """
    Get the currently active serial number for the authenticated user
    """
    serializer_class = SerialNumberSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_object(self):
        return SerialNumber.objects.filter(
            user=self.request.user,
            is_active=True,
            expires_at__gt=timezone.now()
        ).first()

class SerialNumberHistoryAPIView(generics.ListAPIView):
    """
    Get the serial number history for the authenticated user
    """
    serializer_class = SerialNumberSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        return SerialNumber.objects.filter(
            user=self.request.user
        ).order_by('-activated_at')

class RechargeRequestCreateAPIView(generics.CreateAPIView):
    """
    Create a new recharge request
    """
    serializer_class = RechargeRequestCreateSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def perform_create(self, serializer):
        # Check if user already has an active serial
        active_serial = SerialNumber.objects.filter(
            user=self.request.user,
            is_active=True,
            expires_at__gt=timezone.now()
        ).exists()
        
        # Check if user has pending recharge request
        pending_recharge = RechargeRequest.objects.filter(
            user=self.request.user,
            status='pending'
        ).exists()
        
        if active_serial:
            return Response(
                {"detail": "You already have an active serial number."},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        if pending_recharge:
            return Response(
                {"detail": "You already have a pending recharge request."},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        serializer.save(user=self.request.user, status='pending')

class RechargeRequestStatusAPIView(generics.ListAPIView):
    """
    Get the recharge request status for the authenticated user
    """
    serializer_class = RechargeRequestSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        return RechargeRequest.objects.filter(
            user=self.request.user
        ).order_by('-requested_at')[:5]

class ValidateSerialAPIView(APIView):
    """
    Validate a serial number and register the exe hash on first validation
    """
    permission_classes = []  # Public endpoint
    
    def post(self, request, *args, **kwargs):
        serializer = ValidateSerialSerializer(data=request.data)
        
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        serial_code = serializer.validated_data['serial_code']
        exe_hash = serializer.validated_data['exe_hash']
        
        # Find the serial number
        try:
            serial = SerialNumber.objects.get(code=serial_code, is_active=True)
        except SerialNumber.DoesNotExist:
            return Response(
                {"error": "Invalid or inactive serial number."},
                status=status.HTTP_404_NOT_FOUND
            )
            
        # Check if serial is expired
        if serial.is_expired():
            return Response(
                {"error": "This serial number has expired."},
                status=status.HTTP_400_BAD_REQUEST
            )
            
        # If this is the first validation, register the exe hash
        if not serial.exe_hash:
            serial.exe_hash = exe_hash
            serial.first_validated_at = timezone.now()
            serial.save()
            
        # If hash doesn't match, reject the validation
        elif serial.exe_hash != exe_hash:
            return Response(
                {"error": "This serial number is registered to a different executable."},
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Return the serial data
        serializer = SerialNumberSerializer(serial)
        return Response(serializer.data) 