#!/bin/bash

# Stop any running containers
echo "Stopping any running containers..."
docker-compose -f docker-compose.prod.yml down

# Build and start the containers in detached mode
echo "Building and starting containers in production mode..."
docker-compose -f docker-compose.prod.yml up --build -d

# Show the status of the running containers
echo "Container status:"
docker-compose -f docker-compose.prod.yml ps

echo "Production environment is now running with Cloudflare Tunnel."
echo "Your Django site should be accessible through your Cloudflare Tunnel domain."
echo "Tunnel logs can be viewed with: docker-compose -f docker-compose.prod.yml logs -f cloudflared" 